/*
   Ejemplo del Pattern de arquitectura Layer
   guillermo pantaleo 23/08/2002
*/

#include "capa1.h"
#include "capa2.h"
#include "capa3.h"

void main() {


   // instancio las capas
   Capa1 capa1;
   Capa2 capa2;
   Capa3 capa3;

   // relaciono capas de arriba hacia abajo
   capa3.setL2Provider(&capa2);
   capa2.setL1Provider(&capa1);

   // relaciono capas de abajo hacia arriba
   capa1.setNotifica2(&capa2);
   capa2.setNotifica3(&capa3);

   // solicito servicio
   std::cout << "Aplicacion solicita servicio Capa3 .... >" << std::endl << std::endl;
   capa3.Servicio();

}
