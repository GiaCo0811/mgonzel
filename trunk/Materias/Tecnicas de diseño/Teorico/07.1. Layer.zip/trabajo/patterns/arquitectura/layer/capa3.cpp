#include "capa3.h"

bool Capa3::Servicio() { 
        
    std::cout<< "Servicio Capa3" << std::endl;
    std::cout<< "Capa 3 solicita servicio Capa2 .... >" << std::endl << std::endl;
    return capa2->Servicio();
    
}

bool Capa3::Notifica() { std::cout << "Capa3 notificada < ...." << std::endl << std::endl;
                  return true;
}
