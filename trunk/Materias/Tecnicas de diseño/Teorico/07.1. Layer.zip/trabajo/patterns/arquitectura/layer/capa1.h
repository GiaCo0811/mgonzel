#ifndef CAPA1_H
#define CAPA1_H

#include "layerA.h"
#include <iostream>

class Capa1 : public L1Provider , public Notifica1
{
public:
    
     bool Servicio();
     bool Notifica();
};

#endif