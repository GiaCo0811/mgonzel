#include "capa1.h"

bool Capa1::Servicio() {
    std::cout<< "Servicio Capa1 " << std::endl;
    return Notifica();
}

bool Capa1::Notifica() { 

   std::cout<< "Notifica Capa1  ...." << std::endl << std::endl;
   return notifica2->Notifica();

}