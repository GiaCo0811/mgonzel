#ifndef CAPA3_H
#define CAPA3_H

#include "layerA.h"
#include <iostream>

class Capa3 : public L3Provider, public Notifica3
{
public:

   bool Servicio();
   bool Notifica();

};

#endif