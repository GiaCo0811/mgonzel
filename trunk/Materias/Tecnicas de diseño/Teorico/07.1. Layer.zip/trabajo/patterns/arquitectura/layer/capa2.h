#ifndef CAPA2_H
#define CAPA2_H

#include "layerA.h"
#include <iostream>

class Capa2 : public L2Provider, public Notifica2
{
public:
   
    bool Servicio();
    bool Notifica();

};

#endif