#ifndef LAYERA_H
#define LAYERA_H

class L1Provider
{

public:
    virtual bool Servicio()=0;

};
//-----------------------------------
class L2Provider
{

public:
   
    void setL1Provider(L1Provider* c1){ capa1 = c1;}


    virtual bool Servicio()=0;

protected:

       L1Provider* capa1;

};
//------------------------------------
class L3Provider
{

public:

    void setL2Provider(L2Provider* c2){ capa2 = c2;}

    virtual bool Servicio()=0;

protected:

       L2Provider* capa2;

};
//------------------------------------
class Notifica3 {

    public:
    Notifica3(){}

    virtual bool Notifica()=0;

protected:
   
  
};
//------------------------------------
class Notifica2 {

    public:

    void setNotifica3(Notifica3* n3){ notifica3 = n3;}

    virtual bool Notifica()=0;

protected:
   
    Notifica3* notifica3;

};
//------------------------------------
class Notifica1 {

    public:
    
    void setNotifica2(Notifica2* n2){ notifica2 = n2;}

    virtual bool Notifica()=0;

protected:

       Notifica2* notifica2;

};
//------------------------------------



#endif