#include "capa2.h"

bool Capa2::Servicio() { 

    std::cout<< "Servicio Capa2" << std::endl;
    std::cout<< "Capa 2 solicita servicio Capa1 .... >" << std::endl<< std::endl;
    return capa1->Servicio();
   
}

bool Capa2::Notifica() { 
    
    std::cout<< "Capa2 notificada < ...." << std::endl << std::endl;
    notifica3->Notifica();
    return true;
}