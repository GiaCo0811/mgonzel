/************************************************

   solucion: PROTOTYPE
   declaracion de las clases de derivadas  
   de factories, 

  autor : guillermo pantaleo

************************************************/
#ifndef PROTOTYPE_H_
#define PROTOTYPE_H_

#include "..\abstractfactory\factory.h"

class Prototype : public Factory
{
   
public:

	void      Inicialize(Todo* t, Parte* pa, Elemento* elem)      
						{ todo = t;
	                      parte = pa;
						  elemento = elem;
						}
   
	
	Todo*     MakeTodo()     { return  todo->Clone();}
	Parte*    MakeParte()    { return parte->Clone();}
    Elemento* MakeElemento() { return elemento->Clone();}
    
private :

	friend SingletonTemplate<Prototype>;

	Prototype():todo(0), parte(0), elemento(0){} 
	Prototype(const Prototype&);
	Prototype& operator=(const Prototype&);

	Todo*     todo;
	Parte*    parte;
	Elemento* elemento;

};

// singleton template
typedef SingletonTemplate<Prototype> PrototypeSingleton;

#endif