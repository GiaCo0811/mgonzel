/************************************************
 
 SINGLETON
 implementado con referencia 

  autor : guillermo pantaleo
************************************************/
#ifndef  SINGLETON_H_
#define  SINGLETON_H_

class Singleton
{

   public:
      
	   static Singleton& Instance();
       

	   float getDato()        { return dato;}
	   void  setDato(float d) { dato = d;}

	   ~Singleton(){ }	    

   private:

       Singleton(){}
	   Singleton(const Singleton&);
	   Singleton& operator=(const Singleton&);
	   
	   float  dato;
	  
};
//---------------------------------
inline Singleton& Singleton::Instance()
{
   static Singleton object;

   return object;
}

#endif