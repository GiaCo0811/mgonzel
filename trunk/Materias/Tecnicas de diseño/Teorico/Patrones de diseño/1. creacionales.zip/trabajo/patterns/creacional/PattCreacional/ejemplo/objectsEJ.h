/********************************************************
   declaracion y definicion de las clases que modelan
   el problema a resolver. Se trata de un Todo formado
   por partes y a su vez las partes estan constituidas
   por elementos. Las partes son las propietarias de sus 
   elementos, luego son reponsables de liberar la memoria
   asociada a ellas.

  autor : guillermo pantaleo
********************************************************/
#ifndef EJEMPLO_H_
#define EJEMPLO_H_

#pragma warning ( disable : 4150 )

#include <string>
#include <vector>

using namespace std;


class Parte;
class Todo
{

public:

	Todo(){}

    Todo(const Todo&);

	virtual ~Todo(){ for(int i = 0; i < partes.size(); i++)
	                       delete partes[i];}

	virtual Todo* Clone() = 0;
  
    virtual int procesar() = 0;

    void SetParte(Parte* p){ partes.push_back(p);}
   
    virtual string toString() = 0;
   
protected :

    vector<Parte*>  partes;
    
};

//------------------------------------------------------
//  especializacion de los distintos tipos de Todo
//------------------------------------------------------

class TodoTipo1 : public Todo
{
public :
    TodoTipo1():Todo(){}
    TodoTipo1(const TodoTipo1& tp):Todo(tp){}
	Todo* Clone() { return new TodoTipo1(*this);}
	int procesar(){ return 1;}
	string toString() { return "TodoTipo1 \n";}
};

class TodoTipo2 : public Todo
{
public :
    TodoTipo2():Todo(){}
    TodoTipo2(const TodoTipo2& tp):Todo(tp){}
	Todo* Clone() { return new TodoTipo2(*this);}
	int procesar(){ return 2;}
	string toString() { return "TodoTipo2 \n";}
};
//---------------------------------------------
//   definicion de las clases que forman parte
//   de la composicion de un Todo
//---------------------------------------------
class Elemento;
class Parte
{
public:

	Parte(){}
	virtual ~Parte(){ for(int i = 0; i < elementos.size(); i++)
	                       delete elementos[i];	}

    Parte(const Parte& r);

	void SetElemento(Elemento* pe){ elementos.push_back(pe);}

	virtual string ToString() = 0;

    virtual Parte* Clone() = 0;

private:
	
	vector<Elemento*> elementos;
};
//----------------------------------------
class Elemento
{
public:

	Elemento():e(0){}
    virtual ~Elemento(){}

	int Get(){ return e;}
	void Set(int i){e = i;}

    Elemento* Clone() { return new Elemento(*this);}
private:

	int e; 
};
//--------------------
class ParteTipo1 : public Parte
{

   public :

	   ParteTipo1():Parte(){}
	   virtual ~ParteTipo1(){}
       ParteTipo1(const ParteTipo1& rp):Parte(rp){}

	   string ToString(){ return "ParteTipo1";}

       Parte* Clone() { return new ParteTipo1(*this);}

   private :
  

};

class ParteTipo2 : public Parte
{

public :

	   ParteTipo2():Parte(){}
	   virtual ~ParteTipo2(){}
       ParteTipo2(const ParteTipo2& rp):Parte(rp){}

	   string ToString(){ return "ParteTipo2";}

       Parte* Clone() { return new ParteTipo2(*this);}

private :
  

};
/////////////////////////////////////////////////////////
Parte::Parte(const Parte& r) {

   elementos = r.elementos;
   vector<Elemento*>::const_iterator it = r.elementos.begin();
   while(it != r.elementos.end()) {

       elementos.push_back((*it)->Clone());


   }
}
//-----------------------------------------------
Todo::Todo(const Todo& tr) {

   partes = tr.partes;
   vector<Parte*>::const_iterator it = tr.partes.begin();
   while(it != tr.partes.end()) {

       partes.push_back((*it)->Clone());


   }
}

#endif