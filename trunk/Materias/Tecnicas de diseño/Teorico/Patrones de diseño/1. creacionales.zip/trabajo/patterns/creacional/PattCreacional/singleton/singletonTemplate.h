/************************************************
 
 SINGLETON_TEMPLATE
 nota: modela el comportamiento generico de 
 cualquier Singleton

  autor: guillermo pantaleo
************************************************/
#ifndef  SINGLETON_TEMPLATE
#define  SINGLETON_TEMPLATE

template<typename T>
class SingletonTemplate
{

   public:
      
	   static T& Instance(){

                  static T object;

                  return object;
	   }
       
	   
	   ~SingletonTemplate(){ }	    

   private:

       SingletonTemplate(){}
	   SingletonTemplate(const SingletonTemplate&);
	   SingletonTemplate& operator=(const SingletonTemplate&);
};
#endif