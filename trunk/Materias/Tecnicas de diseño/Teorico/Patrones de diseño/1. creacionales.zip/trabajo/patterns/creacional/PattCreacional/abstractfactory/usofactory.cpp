/********************************************************

  CREATIONAL PATTERNS
  
   Modo de uso : ABSTRACT FACTORY
   

  autor : guillermo pantaleo
*********************************************************/

#include <iostream>

#include "factory.h"

// codigo clausurado ante cambios ------
void ProcesaTodoTipos(Factory& aFactory) {

    
     Todo*     todo = aFactory.MakeTodo();
     Parte* parte   = aFactory.MakeParte();
                        
     Elemento* elemento1 = aFactory.MakeElemento();
     Elemento* elemento2 = aFactory.MakeElemento();

     elemento1->Set(10);
     elemento2->Set(100);

     parte->SetElemento(elemento1);
     parte->SetElemento(elemento2);

     todo->SetParte(parte);
     
     todo->procesar();

     cout << "Procesando :" << todo->toString() << endl;

     delete todo;

};
//-----------------------------------

void main(int argc, char *argv[ ])
{
  // seleccion los tipos a construir
  string tipo_construccion = "Procesador1"; // valor default

  if(argc > 1){
	 tipo_construccion = argv[1];
  }
	
  cout << "ABSTRACT FACTORY: " << endl;

  if(strcmp(tipo_construccion.c_str(), "Procesador1") == 0){
   
      FactoryTodoTipo1& factoryTipo1 = FactoryTodoTipo1Singleton::Instance(); 

      ProcesaTodoTipos(factoryTipo1);
 
  }
  else if(strcmp(tipo_construccion.c_str(), "Procesador2") == 0){

      FactoryTodoTipo2& factoryTipo2 = FactoryTodoTipo2Singleton::Instance();
      
      ProcesaTodoTipos(factoryTipo2);

  }



}