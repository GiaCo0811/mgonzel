/************************************************

  Solucion: FACTORY METHOD
  declaracion de la clase que redefine el metodo
  donde se instancian los objetos 

  autor: guillermo pantaleo
************************************************/
#ifndef FACTORYMETHOD_H_
#define FACTORYMETHOD_H_

#include "..\ejemplo\uso.h"

class Procesador2 : public Procesador1
{
public:

	Procesador2(){}
	virtual ~Procesador2(){}

      
    virtual Todo* ArmaTodo(){

	                 Todo*             todo = new TodoTipo2;
                     ParteTipo2* parteTipo2 = new ParteTipo2;
                                                             
                     Elemento* elemento1 = new Elemento;
                     Elemento* elemento2 = new Elemento;

                     elemento1->Set(10);
                     elemento2->Set(100);
                     
                     parteTipo2->SetElemento(elemento1);
                     parteTipo2->SetElemento(elemento2);

                     todo->SetParte(parteTipo2);
                     
                     todo->procesar();

                     todo->procesar();

                     return todo;
	}


};


//--------------------
class Procesador3 
{

   public:
       Procesador3(){}

       Todo* ArmaTodo() { return new TodoTipo2;}
};
//---------------------
template <class T>
class FactoryMethod : public Procesador1 {

public:

    Todo* ArmaTodo() { return t.ArmaTodo();}

private:

    T t;

};

#endif