/************************************************

   solucion: ABSTRACT FACTORY
   declaracion de las clases de la jerarquia 
   de factories

  autor : guillermo pantaleo
************************************************/

#ifndef ABSTRACTFACTORY_H 
#define ABSTRACTFACTORY_H
 

#include "..\ejemplo\objectsEJ.h"
#include "..\singleton\singletonTemplate.h"

class  Factory
{
   
public:
	
   virtual Todo*      MakeTodo()     = 0;
   virtual Parte*     MakeParte()    = 0;
   virtual Elemento*  MakeElemento() = 0;
  
};
//------------------------------------------
class FactoryTodoTipo1 :public  Factory
{
   
public :
	
   Todo*      MakeTodo()   { return new TodoTipo1;}
   Parte*     MakeParte() { return new ParteTipo1;}
   Elemento*  MakeElemento() { return new Elemento;}
   

private:
   friend SingletonTemplate<FactoryTodoTipo1>;

    FactoryTodoTipo1(){} 
	FactoryTodoTipo1(const FactoryTodoTipo1&);
	FactoryTodoTipo1& operator=(const FactoryTodoTipo1&);

};

class FactoryTodoTipo2 :public  Factory
{
   
public:
	
   Todo*      MakeTodo()   { return new TodoTipo2;}
   Parte*     MakeParte()  { return new ParteTipo2;}
   Elemento*  MakeElemento() { return new Elemento;}
   
   
private:
   friend SingletonTemplate<FactoryTodoTipo2>;

   FactoryTodoTipo2(){} 
   FactoryTodoTipo2(const FactoryTodoTipo2&);
   FactoryTodoTipo2& operator=(const FactoryTodoTipo2&);

};

// singleton template
typedef SingletonTemplate<FactoryTodoTipo1> FactoryTodoTipo1Singleton;
typedef SingletonTemplate<FactoryTodoTipo2> FactoryTodoTipo2Singleton;


#endif