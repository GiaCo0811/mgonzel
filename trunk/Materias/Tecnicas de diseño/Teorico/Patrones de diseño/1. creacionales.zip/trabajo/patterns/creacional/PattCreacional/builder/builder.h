/************************************************

   solucion: BUILDER
   declaracion de las clases de la jerarquia 
   de builders

  autor : guillermo pantaleo
************************************************/

#ifndef BUILDER_H_
#define BUILDER_H_

#include "..\ejemplo\objectsEJ.h"
#include "..\singleton\singletonTemplate.h"

class  Builder
{
   
public:
	
   virtual Todo*      MakeTodo()   = 0;
   virtual Parte*     MakeParte()  = 0;
   
   
};

class BuilderTodoTipo1 :public  Builder
{
   
public :
	
   Todo*      MakeTodo();
   Parte*     MakeParte();
   
private:

   friend SingletonTemplate<BuilderTodoTipo1>;

   BuilderTodoTipo1(){} 
   BuilderTodoTipo1(const BuilderTodoTipo1&);
   BuilderTodoTipo1& operator=(const BuilderTodoTipo1&);

};
//-----------------------------------------------
Todo* BuilderTodoTipo1::MakeTodo()
{ 
	return new TodoTipo1;
}

Parte* BuilderTodoTipo1::MakeParte()
{
	ParteTipo1* pa = new ParteTipo1;

	Elemento* elemento1 = new Elemento;
	Elemento* elemento2 = new Elemento;
    elemento1->Set(10);
	elemento2->Set(100);
    

	pa->SetElemento(elemento1);
    pa->SetElemento(elemento2);
    pa->SetElemento(elemento2);

    return pa;
}
/************************************************/
class BuilderTodoTipo2 :public  Builder
{
   
public:
	
   Todo*      MakeTodo();
   Parte*     MakeParte();
  

   private:

   friend SingletonTemplate<BuilderTodoTipo2>;

   BuilderTodoTipo2(){} 
   BuilderTodoTipo2(const BuilderTodoTipo2&);
   BuilderTodoTipo2& operator=(const BuilderTodoTipo2&);

};
//-----------------------------------------------
Todo* BuilderTodoTipo2::MakeTodo()
{ 
	return new TodoTipo2;
}

Parte* BuilderTodoTipo2::MakeParte()
{
	ParteTipo2* pa = new ParteTipo2;
	
	Elemento* elemento1 = new Elemento;
    elemento1->Set(1);
	pa->SetElemento(elemento1);

    Elemento* elemento2 = new Elemento;
    elemento1->Set(103);
	pa->SetElemento(elemento2);

    Elemento* elemento3 = new Elemento;
    elemento1->Set(10000);
	pa->SetElemento(elemento3);

    Elemento* elemento4 = new Elemento;
    elemento1->Set(19999);
	pa->SetElemento(elemento4);
    
    return pa;
}

/***********************************************/
// singleton template
typedef SingletonTemplate<BuilderTodoTipo1> BuilderTodoTipo1Singleton;
typedef SingletonTemplate<BuilderTodoTipo2> BuilderTodoTipo2Singleton;

#endif