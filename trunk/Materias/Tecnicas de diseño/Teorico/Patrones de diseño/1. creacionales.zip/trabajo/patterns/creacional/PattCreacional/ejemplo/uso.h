/************************************************

   declaracion de la clase que hace uso de las 
   clases Todo, Parte y Elemento

  autor : guillermo pantaleo
*************************************************/


#ifndef USO_H_
#define USO_H_

#include "objectsEJ.h"


class Procesador1 
{
public :
	
	Procesador1(){}
	virtual ~Procesador1(){}

      
    virtual Todo* ArmaTodo(){      

                     Todo*             todo = new TodoTipo1;
                     ParteTipo1* parteTipo1 = new ParteTipo1;
                                                             
                     Elemento* elemento1 = new Elemento;
                     Elemento* elemento2 = new Elemento;

                     elemento1->Set(10);
                     elemento2->Set(100);
                     
                     parteTipo1->SetElemento(elemento1);
                     parteTipo1->SetElemento(elemento2);

                     todo->SetParte(parteTipo1);
                     
                     todo->procesar();

                     return todo;
   }

};

#endif