/********************************************************
   CREATIONAL PATTERNS 

   Modo de uso : PROTOTYPE
   nota: uso de prototype ( factory ya instanciada)
   modo de uso

  autor : guillermo pantaleo
*********************************************************/

#include <iostream>
#include "prototype.h"


// objetos  ya instanciados !!!!!!!!
TodoTipo2*  todo_original = new TodoTipo2;
ParteTipo2* pa            = new ParteTipo2;             
Elemento*   elem          = new Elemento;

// codigo clausurado ante cambios ------
void ProcesaTodoTipos(Factory& prototype) {

     Todo*     todo = prototype.MakeTodo();

     Parte* parte  = prototype.MakeParte();
                        
     Elemento* elemento1 = prototype.MakeElemento();
     Elemento* elemento2 = prototype.MakeElemento();

     elemento1->Set(10);
     elemento2->Set(100);

     parte->SetElemento(elemento1);
     parte->SetElemento(elemento2);

     todo->SetParte(parte);
     
     todo->procesar();

     cout << "Procesando :" << todo->toString() << endl;

};
//--------------------------------------

void main()
{
    
   Prototype& prototype = PrototypeSingleton::Instance(); 
   prototype.Inicialize(todo_original, pa, elem); 

   cout << "PROTOTYPE: " << endl;
   
   ProcesaTodoTipos(prototype);

   delete todo_original;
}
