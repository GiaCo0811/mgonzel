/********************************************************
CREATIONAL PATTERNS

   Modo de uso : FACTORY METHOD
   nota: jerarquia de clases

  autor : guillermo pantaleo
*********************************************************/
#include "uso.h"
#include <iostream>

using namespace std;

// codigo clausurado ante cambios ---
void ProcesaTodoTipos(Todo* tt) {

    cout << "Procesando :" << tt->toString() << endl;

};
//--------------------------------------------------
void main()
{
  
  Procesador1 procesador;
  Todo*  todo = procesador.ArmaTodo();

  ProcesaTodoTipos(todo);

  delete todo;

}