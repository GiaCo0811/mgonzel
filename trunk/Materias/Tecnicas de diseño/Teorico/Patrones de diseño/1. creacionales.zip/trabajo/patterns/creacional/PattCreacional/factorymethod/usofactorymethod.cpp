/********************************************************
   CREATIONAL PATTERNS

   Modo de uso : ORIGINAL Y  FACTORY METHOD
   
   autor: guillermo pantaleo
*********************************************************/

#include <iostream>
#include "..\factorymethod\factorymethod.h"


// codigo clausurado ante cambios ----------
void ProcesaTodoTipos(Todo* tt) {

    cout << "Procesando :" << tt->toString() << endl;

};
//------------------------------------------

void main(int argc, char *argv[ ])
{

  // seleccion los tipos a construir
  string tipo_construccion = "Procesador1"; // valor default
  if(argc > 1){
	 tipo_construccion = argv[1];
  }
	
  if(strcmp(tipo_construccion.c_str(), "Procesador1") == 0){

     // USO ORIGINAL
     Procesador1 procesador;
     Todo* todo = procesador.ArmaTodo();

     cout << "CASO ORIGINAL: " << endl;

     ProcesaTodoTipos(todo);
     
     delete todo;
      
  }
  else if(strcmp(tipo_construccion.c_str(), "Procesador2") == 0){

     // FACTORY METHOD (herencia)
     Procesador2  procesador2;
     Todo* todo = procesador2.ArmaTodo();

     cout << "FACTORY METHOD: " <<  endl;

     ProcesaTodoTipos(todo);

     delete todo;
     
  }
  else {

     // FACTORY METHOD (template)
     FactoryMethod<Procesador3> procesador3;
     Todo* todo = procesador3.ArmaTodo();

     cout << "FACTORY METHOD SIN HERENCIA: " <<  endl;

     ProcesaTodoTipos(todo);

     delete todo;



  }

}