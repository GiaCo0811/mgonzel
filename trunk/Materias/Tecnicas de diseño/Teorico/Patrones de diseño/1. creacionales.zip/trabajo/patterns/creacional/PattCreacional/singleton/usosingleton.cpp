/********************************************************
   CREATIONAL PATTERNS

   Modo de uso : SINGLETON
   nota: uso de singleton 
   
     autor : guillermo pantaleo
*********************************************************/
#include "singleton.h"
#include "singletonTemplate.h"
#include <iostream>

using namespace std;


//--------- clase a hacer singleton ----------
class Pepe{

public:

    int   getDato()      { return dato;}
	void  setDato(int d) { dato = d;}

private:

	// condiciones para hacerla singleton
	friend SingletonTemplate<Pepe>;

	Pepe(){}
	Pepe(const Pepe&);
	Pepe& operator=(const Pepe&);

	// atributos
	int dato;

};
//-------------------------------------

void main()
{

   // haciendo privados los contructores evito esto
   //Singleton s5 = Singleton::Instance();

   //Singleton s4 = s5;
	//s4 = s5;
	
	//----------------------------------


    // implementacion usando una referencia


	Singleton& s1 = Singleton::Instance();
	s1.setDato(12.25);

	cout << s1.getDato() << "\n";

    Singleton& s2 = Singleton::Instance();
	
	cout << s2.getDato() << "\n";


	
	// implementacion usando templates
	typedef SingletonTemplate<Pepe> IntSingleton;
    
	Pepe& sT1 = IntSingleton::Instance(); 

	sT1.setDato(1);

	cout << sT1.getDato() << "\n";

	Pepe& sT2 = IntSingleton::Instance(); 

	cout << sT2.getDato() << "\n";
    
   
}