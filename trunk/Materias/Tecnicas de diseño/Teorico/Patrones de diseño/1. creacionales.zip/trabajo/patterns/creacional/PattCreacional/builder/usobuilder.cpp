/********************************************************
 CREATIONAL PATTERNS

   Modo de uso : BUILDER
   nota: jerarquia paralela de builders
   modo de uso
   
     autor : guillermo pantaleo
*********************************************************/

#include <iostream>
#include "builder.h"

// codigo clausurado ante cambios -----
void ProcesaTodoTipos(Builder& builder) {

    Todo*    todo = builder.MakeTodo();
    Parte* parteA = builder.MakeParte();
    Parte* parteB = builder.MakeParte();
    Parte* parteC = builder.MakeParte();

    todo->SetParte(parteA);
    todo->SetParte(parteB);
    todo->SetParte(parteC);

    todo->procesar();

    cout << "Procesando :" << todo->toString() << endl;

    delete todo;

};
//-------------------------------------

void main()
{
  

   
   BuilderTodoTipo1& BuilderTipo1 = BuilderTodoTipo1Singleton::Instance(); 
 
   cout << "BUILDER: " << endl;
   ProcesaTodoTipos(BuilderTipo1);

   

   BuilderTodoTipo2& BuilderTipo2 = BuilderTodoTipo2Singleton::Instance();

   cout << "BUILDER: " << endl;
   ProcesaTodoTipos(BuilderTipo2);

}