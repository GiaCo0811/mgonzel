// modificado por guillermo pantaleo
// el 12/07/2002
// Demonstrates use of StateMachine.java

final class Estado extends StateTT {
  private Estado(String nm) { super(nm); }
  
  // estados posibles ----------------
  public final static Estado
    colgado    = new Estado("Estado: colgado"),
    descolgado = new Estado("Estado: descolgado"),
    discando   = new Estado("Estado: discando"),
    hablando   = new Estado("Estado: hablando");
}
  //----------------------------------
  // entradas posibles ---------------
final class Cuelga implements Input {
    private String name;
    public Cuelga(String s){name = s;}
    public String toString(){return name;}
    public final static Cuelga CUELGA = new Cuelga("Cuelga");
}
final class Descuelga implements Input {
    private String name;
    public Descuelga(String s){name = s;}
    public String toString(){return name;}
    public final static Descuelga DESCUELGA = new Descuelga("Descuelga");
}
final class Disca implements Input {
    private static String name;
    public Disca(String s){name = s;}
    public String toString(){return name;}
    public final static Disca DISCA = new Disca("Disca");
}
final class Atiende implements Input {
    private String name;
    public Atiende(String s){name = s;}
    public String toString(){return name;}
    public final static Atiende ATIENDE = new Atiende("Atiende");
}
final class Digito implements Input {
  private String value;
  private Digito(String val) {
    value = val;
  }
  public String toString() { return value; }
  public String getValue() { return value; }
  public final static Digito
    CERO   = new Digito("0"),
    UNO    = new Digito("1"),
    DOS    = new Digito("2"),
    TRES   = new Digito("3"),
    CUATRO = new Digito("4"),
    CINCO  = new Digito("5"),
    SEIS   = new Digito("6"),
    SIETE  = new Digito("7"),
    OCHO   = new Digito("8"),
    NUEVE  = new Digito("9");
}
   //-------------------------
   // numero discado ---------
class Numero {
  String numero = new String();
  int counter = 0;
  public Numero(){}
  public void addDigito(Digito d) {
      counter++;
      numero+= d.getValue();
  }
  public int getNroDigitos(){return counter;}
  public String toString() { return numero.toString();}
  public void   reset(){ counter = 0; numero = ""; }
}
   //-------------------------
   // clase para la que se modelan los estados
public class LineaTelefonicaTT extends StateMachineTT{
    
  Digito digito = null;
  Numero numero = new Numero();
  
  // condiciones para las transiciones -------
  Condition noLargaDistancia = new Condition() {
    public boolean condition(Input input) {
      String d0 = ((Digito)input).getValue();
      return d0 != "0";
    }
  };
  
  Condition countDigitos = new Condition() {
    public boolean condition(Input input) {
      int digitosDiscados = numero.getNroDigitos();
      return digitosDiscados >= 8;
    }
  };
    // transiciones ---------------------------
  Transition muestraEventos = new Transition() {
    public void transition(Input input) {
      System.out.println( currentState.toString() + " Evento: " + input.toString());
    }
 };
 
  Transition clearDiscado = new Transition() {
    public void transition(Input input) {
      System.out.println( currentState.toString() + " Evento: " + input.toString());
      System.out.println( "Reseteando numero discado: " + numero.toString());
      numero.reset();
    }
 };
 
 Transition discaDigito = new Transition() {
    public void transition(Input input) {
      System.out.println( currentState.toString() + " Disca el digito: " + ((Digito)input).toString());
      numero.addDigito((Digito)input);
    }
 };
    //-------------------------------

  public LineaTelefonicaTT() {
    super(Estado.colgado); // Initial state
       
    // tabla de transicion de estados ---
    buildTable(new Object[][][]{
      { {Estado.colgado}, // Current state
        // Input, test, transition, next state:
        {Cuelga.class,     null,            muestraEventos,        Estado.colgado},
        {Descuelga.class,  null,            muestraEventos,        Estado.descolgado}},
      { {Estado.descolgado}, 
        {Cuelga.class,     null,            muestraEventos,        Estado.colgado},
        {Disca.class,      null,            muestraEventos,        Estado.discando}},
      { {Estado.discando}, 
        {Cuelga.class,     null,            muestraEventos,        Estado.colgado},
        {Digito.class,     noLargaDistancia,discaDigito,           Estado.discando},
        {Atiende.class,    countDigitos,    muestraEventos,        Estado.hablando}},  
      { {Estado.hablando}, 
        {Cuelga.class,     null,            clearDiscado,          Estado.colgado}},  
    });
  }
} 
