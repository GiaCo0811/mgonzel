/*
 * LineaTelefonica.java
 *
 * Created on July 13, 2002, 5:47 PM
 */
// State Machine pattern using 'if' statements
// to determine the next state.
import java.util.*;
import java.io.*;

// A different subclass for each state:
/**
 *
 * @author  guillermo pantaleo
 * @version 
 */

class Colgado implements State {
    
  public void run() { 
    System.out.println("Estado: Telefono colgado");
  }
  
  public State next(Input i) {
    
      Evento ma = (Evento)i;
    
      if(ma.equals(Evento.descuelga))
        return LineaTelefonica.descolgado;
    
      return LineaTelefonica.colgado;
  }
}
//----------------------------------
class Descolgado implements State {
    
  public void run() { 
    System.out.println("Estado: Telefono descolgado");
  }
  
  public State next(Input i) {
    
      Evento ma = (Evento)i;
    
    if(ma.equals(Evento.disca))
      return LineaTelefonica.discando;
    if(ma.equals(Evento.cuelga))
      return LineaTelefonica.colgado;
    
    return LineaTelefonica.descolgado;
  }
}
//----------------------------------
class Discando implements State {
    
  public void run() { 
    System.out.println("Estado: Telefono discando");
  }
  
  public State next(Input i) {
    
      Evento ma = (Evento)i;
    
    if(ma.equals(Evento.atienden))
      return LineaTelefonica.hablando;
    if(ma.equals(Evento.cuelga))
      return LineaTelefonica.colgado;
    
    return LineaTelefonica.discando;
  }
}
//----------------------------------
class Hablando implements State {
    
  public void run() { 
    System.out.println("Estado: Telefono comunicado y hablando");
  }
  
  public State next(Input i) {
    
      Evento ma = (Evento)i;
    
    if(ma.equals(Evento.cuelga))
      return LineaTelefonica.colgado;
    
    return LineaTelefonica.hablando;
  }
}
//------------------------------------
class LineaTelefonica extends StateMachine {

  public static State 
    colgado    = new Colgado(),
    descolgado = new Descolgado(),
    discando   = new Discando(),
    hablando   = new Hablando();
  
  public LineaTelefonica() {
    super(colgado); // Initial state
  }
}
//------------------------------------
public class LineaTelefonicaTest {
  LineaTelefonica linea = new LineaTelefonica();
  SecuenciaEventos eventos = 
    new SecuenciaEventos(
      new StringList("c:\\trabajo\\patterns\\comportamiento\\PattComportamiento\\estado\\LineaTel.txt")
        .iterator());
  
  public void test() {
    linea.runAll(eventos.iterator());
  }
  public static void main(String args[]) {
    new LineaTelefonicaTest().test();
  }
}