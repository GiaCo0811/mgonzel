#include "methodClaves.h"
#include <cctype>

ProcesadorClaves::ProcesadorClaves():ProcesadorDocumento()
{

}
//-----------------------------------------------
void ProcesadorClaves::Procesar(list<string>& palabras_claves,
						        list<string>& palabras_abuscar)
{

    string::size_type j = 0;
	list<string>::iterator  iter_palabras = palabras_claves.begin();
	while(iter_palabras != palabras_claves.end()){

	
       j = 0;

	    if((*iter_palabras)[0] == '\'' && (*iter_palabras)[(*iter_palabras).length() - 1] == '\''){
            
            iter_palabras++;
            continue;
        }
        else if((*iter_palabras).find(" ", j) != string::npos) {

            iter_palabras++;
            continue;
        }
        else {

           palabras_abuscar.push_back(*iter_palabras);
		   iter_palabras++;
 
        }

	}
}


   