/************************************************

  template method 
  este es la declaracion de la clase que modela
  un documento , usada como ejemplo para
  el pattern correspondiente

*************************************************/
#ifndef TEMPLATEMETHOD_H_
#define TEMPLATEMETHOD_H_

#pragma warning ( disable : 4786 )

/*
	una secuencia de funciones determinadas por el metodo
	de procesamiento donde alguno es virtual, nos lleva 
	al template method pattern con estrategias diferentes
*/

#include <list>

using namespace std;


class ProcesadorDocumento
{

public :

   ProcesadorDocumento();
   ~ProcesadorDocumento();

   string& GetTextoProceasdo(){ return texto_procesado;}
   void    SetTextoDocumento(string& s) { texto_doc = s;}

   void ProcesarDocumento();

   virtual void  Procesar( list<string>& palabras_claves, 
						   list<string>& palabras_abuscar) = 0;

protected:

	string       texto_doc;
	string       texto_procesado;

	void ProcesaDocumento(list<string>& palabras_abuscar);
	
};

#endif