// modificado por guillermo pantaleo
// el 12/07/2002
// Condition function object for state machine

public interface Condition {
  boolean condition(Input i);
} 
