/************************************************

  Method : claves
  
*************************************************/
#ifndef METHODCLAVES_H_
#define METHODCLAVES_H_

#pragma warning ( disable : 4786 )

#include "method.h"

class ProcesadorClaves: public ProcesadorDocumento
{

public:

   virtual void  Procesar( list<string>& palabras_claves, 
						   list<string>& palabras_abuscar);

   ProcesadorClaves();
};
#endif