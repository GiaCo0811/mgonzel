/************************************************

  Method: palabras
*************************************************/
#ifndef METHODPALABRAS_H_
#define METHODPALABRAS_H_

#pragma warning ( disable : 4786 )

#include "method.h"

class ProcesadorPalabras: public ProcesadorDocumento
{

public:

   virtual void  Procesar( list<string>& palabras_claves, 
						   list<string>& palabras_abuscar);

   ProcesadorPalabras();
};
#endif