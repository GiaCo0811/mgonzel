#include "methodExpresiones.h"
#include <cctype>

ProcesadorExpresiones::ProcesadorExpresiones():ProcesadorDocumento()
{

}
//-----------------------------------------------
void ProcesadorExpresiones::Procesar(list<string>& palabras_claves, 
						             list<string>& palabras_abuscar)
{

	list<string>::iterator  iter_palabras = palabras_claves.begin();
	while(iter_palabras != palabras_claves.end()){

		
		// los elementos que tienen "", se los saco y los copio
		string::size_type i = 0;
        string::size_type j = 0;
	    string aux;
        
	
		if((*iter_palabras)[0] == '\'' && (*iter_palabras)[(*iter_palabras).length() - 1] == '\''){

            aux = (*iter_palabras).substr(1, (*iter_palabras).length() - 2);
			palabras_abuscar.push_back(aux);
			++iter_palabras;
			continue;
		}
		++iter_palabras;
	}
}

   