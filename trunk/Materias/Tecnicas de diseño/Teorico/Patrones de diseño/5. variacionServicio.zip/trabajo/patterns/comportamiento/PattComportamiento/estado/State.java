// modificado por guillermo pantaleo
// el 12/07/2002
// A State has an operation, and can be moved
// into the next State given an Input:

public interface State {
  void run();
  State next(Input i);
} 
