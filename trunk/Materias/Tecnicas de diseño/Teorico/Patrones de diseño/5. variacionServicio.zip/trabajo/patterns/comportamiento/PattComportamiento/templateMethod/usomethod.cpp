//  PATTERNS DE COMPORTAMIENTO
/********************************************************
   Modo de uso : TEMPLATE METHOD
   
   modo de uso
*********************************************************/
#include "method.h"
#include "methodClaves.h"
#include "methodPalabras.h"
#include "documentoTexto.h"
#include "methodExpresiones.h"

#include <iostream>

using namespace std;

void main()
{
	DocumentoTexto documento("c:\\trabajo\\patterns\\pruebaStrategy.txt");
    cout << "--------- Texto original donde se busca --------- " << endl; 
	documento.Print();

	char c;
    cin >> c;
	
    cout << "--------- Resultado de la busqueda de Expresiones --------- " << endl; 
	ProcesadorExpresiones procesador_expresiones;
	procesador_expresiones.SetTextoDocumento(documento.GetElTexto());
    procesador_expresiones.ProcesarDocumento();
    
	cout << procesador_expresiones.GetTextoProceasdo();

    
    cin >> c;

    cout << "--------- Resultado de la busqueda de palabras claves --------- " << endl;
    ProcesadorClaves  procesador_claves;
	procesador_claves.SetTextoDocumento(documento.GetElTexto());
    procesador_claves.ProcesarDocumento();
    
	cout << procesador_claves.GetTextoProceasdo();
	
    cin >> c;

    cout << "---------  Resultado de la busqueda de palabras compuestas --------- " << endl;
    ProcesadorPalabras procesador_palabras;
	procesador_palabras.SetTextoDocumento(documento.GetElTexto());
    procesador_palabras.ProcesarDocumento();
    
	cout << procesador_palabras.GetTextoProceasdo();
}
