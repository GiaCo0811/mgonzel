
// Transition function object for state machine

public interface Transition {
  void transition(Input i);
} 
