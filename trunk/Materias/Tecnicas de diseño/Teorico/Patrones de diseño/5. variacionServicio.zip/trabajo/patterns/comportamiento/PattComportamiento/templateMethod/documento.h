/************************************************

  Documento 
  este es la declaracion de la clase que modela
  un documento , usada como ejemplo para
  distintos patterns

*************************************************/
#ifndef DOCUMENTO_H_
#define DOCUMENTO_H_

#include <string>

using namespace std;

class Documento
{


public:

	Documento(const char* nombre_file):nombre_file(nombre_file){}
	
	virtual ~Documento(){}

	// manejo del contenido como txt
	virtual string& GetElTexto(){ return el_texto;}
	virtual void    SetElTexto(string s){ el_texto = s;}
	virtual bool    Print()=0;

	// manejo del file
	virtual bool SaveToFile(const char* nombre_file)  {return false;}
	virtual bool LoadFromFile(const char* nombre_file){return false;}
	const char*  getNombreFile(){ return nombre_file.c_str();}
private:

	Documento(const Documento&);
	Documento& operator=(const Documento&);

protected:

	string el_texto;
	string nombre_file;

	
};
#endif