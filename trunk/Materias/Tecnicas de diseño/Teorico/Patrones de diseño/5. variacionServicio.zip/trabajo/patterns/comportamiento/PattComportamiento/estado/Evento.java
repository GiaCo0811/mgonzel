/*
 * Eventos.java
 *
 * Created on July 13, 2002, 6:15 PM
 */
/**
 *
 * @author  guillermo pantaleo
 * @version 
 */

public class Evento implements Input {
  private String action;
  
  public Evento(String a) { action = a; }
  
  public String toString() { return action; }
  
  public int hashCode() { 
    return action.hashCode();
  }
  
  public boolean equals(Object o) {
    return (o instanceof Evento)
      && action.equals(((Evento)o).action);
  }
  
  public static Evento
    descuelga = new Evento("evento -> descuelga telefono"),
    cuelga    = new Evento("evento -> cuelga telefono"),
    disca     = new Evento("evento -> disca digito de numero telefonico"),
    atienden  = new Evento("evento -> atiende abonado llamado");
} 
