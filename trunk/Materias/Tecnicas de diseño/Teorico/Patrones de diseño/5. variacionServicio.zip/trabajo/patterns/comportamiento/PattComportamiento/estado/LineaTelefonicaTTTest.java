// Demonstrates use of StateMachine.java

public class LineaTelefonicaTTTest {
  LineaTelefonicaTT lt = new LineaTelefonicaTT();
  Input[] inputs = {
    Cuelga.CUELGA,
    Descuelga.DESCUELGA,
    Disca.DISCA,
    //Digito.CERO, //descomentar
    Digito.UNO,
    Digito.DOS,
    Digito.TRES,
    Digito.CUATRO,
    Digito.CINCO,
    Digito.SEIS,
    Digito.SIETE,
    //Digito.OCHO, // comentar
    Atiende.ATIENDE,
    Cuelga.CUELGA,
    Cuelga.CUELGA
  };
  public void test() {
    for(int i = 0; i < inputs.length; i++)
      lt.nextState(inputs[i]);
  }
  public static void main(String[] args) {
    new LineaTelefonicaTTTest().test();
  }
} 
