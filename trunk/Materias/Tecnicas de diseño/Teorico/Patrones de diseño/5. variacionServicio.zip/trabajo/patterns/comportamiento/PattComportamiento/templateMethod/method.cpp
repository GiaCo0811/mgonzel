/************************************************

  template method
  implementacion de los distintos algoritmos segun
  las distintas estrategias

*************************************************/
#include "method.h"
#include <cctype>

ProcesadorDocumento::ProcesadorDocumento()
:texto_doc(""), texto_procesado("")
{
}
//-----------------------------------------------
ProcesadorDocumento::~ProcesadorDocumento()
{
	
}
//-----------------------------------------------
void ProcesadorDocumento::ProcesarDocumento()
{
    // prepara las palabras claves
    list<string> palabras_claves;

	palabras_claves.push_back("malo");
    palabras_claves.push_back("nada bueno");
	palabras_claves.push_back("'objeto clase'");
	palabras_claves.push_back("Diego");


	// lista llenada de acuerdo a las distintas
	// estrategias
	list<string> palabras_abuscar;
	
	Procesar(palabras_claves, palabras_abuscar);

	ProcesaDocumento(palabras_abuscar);
}
//-----------------------------------------------
void ProcesadorDocumento::ProcesaDocumento(list<string>& palabras_abuscar)
{
	// se procesa el texto
	list<string>::iterator  iter_palabras = palabras_abuscar.begin();
	while(iter_palabras != palabras_abuscar.end()){

	   string::size_type i = 0;
       string::size_type j = 0;
       string::size_type k = 0;
	   string aux;

	   while((i = texto_doc.find(*iter_palabras, i)) != string::npos){

		   if(isalpha((*iter_palabras)[0])){
	   
			   // la palabra clave se pasa a mayusculas
			   aux = *iter_palabras;
			   char* dumy = _strdup(aux.c_str());
			   aux.replace(0, aux.size(), _strupr(dumy));
           

               // se copia la linea que la contiene
			   j = texto_doc.find("\n", i);
			   i = texto_doc.rfind("\n", i);
			   if(i == string::npos) i = 0;
			   
			   // con lo encontrado en mayusculas
   			   string aux2 = texto_doc.substr(i, j - i);
               k = 0;
               k = aux2.find(*iter_palabras, k);
               aux2.replace(k, aux.size(), aux.c_str());

			   texto_procesado += aux2;
			   texto_procesado += "\n";
		   }
		   if(j != string::npos){
		      j++;
              i = j;
		   }
		   else break;
	   }

	   ++iter_palabras;
	}
}
