/************************************************

  DocumentoTexto 
  este es la declaracion de la clase que modela
  un DocumentoTexto de texto, usada como ejemplo para
  distintos patterns

*************************************************/
#ifndef DOCUMENTOTEXTO_H_
#define DOCUMENTOTEXTO_H_

#include"documento.h"

#include <string>

using namespace std;

class DocumentoTexto : public Documento
{


public:

	DocumentoTexto(const char* nombre_file);
	
	virtual ~DocumentoTexto();

	// manejo del texto
	string& GetElTexto(){ return el_texto;}
	void    SetElTexto(string s){ el_texto = s;}
    bool    Print();

	// manejo del file
	bool SaveToFile(const char* nombre_file);
	bool LoadFromFile(const char* nombre_file);
	
private:

    
	DocumentoTexto(const DocumentoTexto&);
	DocumentoTexto& operator=(const DocumentoTexto&);

protected:

	
};
#endif