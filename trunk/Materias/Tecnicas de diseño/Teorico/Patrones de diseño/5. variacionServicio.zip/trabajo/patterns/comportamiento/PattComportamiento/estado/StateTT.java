// modificado por guillermo pantaleo
// el 12/07/2002
public class StateTT {
  private String name;
  
  public StateTT(String nm) { name = nm; }
  
  public String toString() { return name; }
} 
