#include "methodPalabras.h"
#include <cctype>

ProcesadorPalabras::ProcesadorPalabras():ProcesadorDocumento()
{

}
//-----------------------------------------------
void ProcesadorPalabras::Procesar(list<string>& palabras_claves, 
						          list<string>& palabras_abuscar)
{

	list<string>::iterator  iter_palabras = palabras_claves.begin();
	while(iter_palabras != palabras_claves.end()){

		// en cada elemento de la lista de claves busco espacios
		// si los hay, separo cada palabra del elemento en un elemento
		// de la lista de busqueda
		// los elementos sueltos los copio tala cual
		// los elementos que tienen '', se los saco y los copio
		
        
        if((*iter_palabras)[0] == '\'' && (*iter_palabras)[(*iter_palabras).length() - 1] == '\''){
            
            ++iter_palabras;
            continue;
        }
        
        
        string::size_type i = 0;
        string::size_type j = 0;
	    string aux;
        
		
		
		i = 0;
		j = 0;
		while((j = (*iter_palabras).find(" ", j)) != string::npos){

            aux = (*iter_palabras).substr(i, j - i);
            palabras_abuscar.push_back(aux);
			
			if(j != string::npos){ 
			   j++;
			   i = j;  
			}
			else
				break;
		}
			
		if(i != 0){ // copia la ultima palabra

			aux = (*iter_palabras).substr(i, j - i);
            palabras_abuscar.push_back(aux);

		}
        		
		++iter_palabras;

	}
}

   