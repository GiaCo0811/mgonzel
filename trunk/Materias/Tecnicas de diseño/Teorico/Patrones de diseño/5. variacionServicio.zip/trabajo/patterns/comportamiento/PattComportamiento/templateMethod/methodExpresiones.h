/************************************************

  Method : expresiones

*************************************************/
#ifndef METHODEXPRESIONES_H_
#define METHODEXPRESIONES_H_

#pragma warning ( disable : 4786 )

#include "method.h"

class ProcesadorExpresiones: public ProcesadorDocumento
{

public:

   virtual void  Procesar( list<string>& palabras_claves, 
						   list<string>& palabras_abuscar);

   ProcesadorExpresiones();
};
#endif