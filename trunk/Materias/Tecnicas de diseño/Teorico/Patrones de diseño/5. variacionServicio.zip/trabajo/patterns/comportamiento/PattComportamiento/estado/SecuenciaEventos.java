/*
 * SecuenciaEventos.java
 *
 * Created on July 13, 2002, 6:12 PM
 */
/**
 *
 * @author  guillermo pantaleo
 * @version 
 */

import java.util.*;

public class SecuenciaEventos extends ArrayList {
  public SecuenciaEventos(Iterator sit) {
    while(sit.hasNext())
      add(new Evento((String)sit.next()));
  }
}
