// modificado por guillermo pantaleo
// el 12/07/2002
// A table-driven StateTT machine
import java.util.*;

public class StateMachineTT {
    
  protected StateTT currentState;
  private Map map = new HashMap();
  
  public StateMachineTT(StateTT initial) {
    currentState = initial;
  }
  
  public void buildTable(Object[][][] table) {
   
      for(int i = 0; i < table.length; i++) {
      
          Object[][] row = table[i];
          Object currentState = row[0][0];
          List transitions = new ArrayList();
      
          for(int j = 1; j < row.length; j++)
             transitions.add(row[j]);
          map.put(currentState, transitions);
      }
  }
  
  public void nextState(Input input) {
      
    // para el estado corriente recorro las posibles transiciones  
    Iterator it=((List)map.get(currentState)).iterator();
    while(it.hasNext()) {
      Object[] tran = (Object[])it.next();
      if(input == tran[0] || 
         input.getClass() == tran[0]) { // testeo entrada
         
          if(tran[1] != null) {         // testeo condicion
              Condition c = (Condition)tran[1];
              if(!c.condition(input))
                 continue; // Failed test
          }
          if(tran[2] != null)          // ejecuto accion y cambio de estado
             ((Transition)tran[2]).transition(input);
          currentState = (StateTT)tran[3];
          return;
      }
    }
    throw new RuntimeException(
      "Entrada: " +  input.toString()+ " no valida para el  " + currentState.toString());
  }
} 
