// modificado por guillermo pantaleo
// el 12/07/2002
// Inputs to a state machine
public interface Input {} 
