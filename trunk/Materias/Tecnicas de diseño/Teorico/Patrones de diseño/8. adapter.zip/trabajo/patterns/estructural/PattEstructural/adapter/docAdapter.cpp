#include "data.h"
#include "docAdapter.h"

#include <iostream>

using namespace std;

DocumentoData::DocumentoData(const char* file)
:DocumentoTexto(file), data( *new Data(file))
{}
//-----------------------------------------------------
bool DocumentoData::Print()
{

	int i = 0;
	data.GoTop();
	while(data.HasNext()){
	
		cout << "DATO [" << i << "] : ";
		cout << data.Next() << "\n";
		i++;

	}

   return true;
}
//-----------------------------------------------
DocumentoData::~DocumentoData() 
{

    delete &data;
}