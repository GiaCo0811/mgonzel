/************************************************

  DocumentoTexto

  funciones de la clase ejemplo del pattern
  Decorator

************************************************/
#include "DocumentoTexto.h"
#include <iostream>
#include <fstream>


using namespace std;


DocumentoTexto::DocumentoTexto(const char* file):Documento(file)
{
}
//--------------------------------------
DocumentoTexto::~DocumentoTexto()
{

}
//--------------------------------------
bool DocumentoTexto::Print()
{
	if(el_texto.size() == 0){
       
		LoadFromFile(nombre_file.c_str());
	}

   cout << el_texto.c_str() << "\n";

   return true;
}
//--------------------------------------
bool DocumentoTexto::SaveToFile(const char* nombre_file)
{
   ofstream* file = new ofstream( nombre_file , ios_base::app);

   if(file->is_open()){
      
	   *file << el_texto.c_str();
	   file->close();
	   
   }
   else{

      // exception

   }
   delete file;
   return true;
}
//--------------------------------------
bool DocumentoTexto::LoadFromFile(const char* nombre_file)
{
   ifstream* file = new ifstream( nombre_file , ios_base::in);

   if(file->is_open()){
      
	   char c;
	   while(file->get(c)){
		   
		   el_texto += c;

	   }
	   

      // *file >> el_texto; // para en los blancos ????

	   file->close();
	   
   }
   else{



   }

   delete file;
   return true;
}