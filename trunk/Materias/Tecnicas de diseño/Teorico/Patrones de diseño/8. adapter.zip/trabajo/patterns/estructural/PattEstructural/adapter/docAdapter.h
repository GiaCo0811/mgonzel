/************************************************

  DocAdapter 
  este es la declaracion de la clase que modela
  un documento , usada como ejemplo para
  distintos patterns

*************************************************/
#ifndef DOCADAPTER_H_
#define DOCADAPTER_H_

#include "documentoTexto.h"

class Data;
class DocumentoData : public DocumentoTexto
{

public:

	DocumentoData(const char* file);
	~DocumentoData();
    
	bool Print();

private:

	// referencia al componente adaptado
	Data& data;

};

#endif