/************************************************

  Data 
  este es la declaracion de la clase que modela
  un Data de texto, usada como ejemplo para
  distintos patterns

*************************************************/
#ifndef DATA_H_
#define DATA_H_

#include <vector>

using namespace std;

class Data
{


public:

	Data(const char* nombre_file);
	
	virtual ~Data(){}

	// manejo del contenido como txt
	bool   HasNext(){ return iter !=  datos.end();}
	void   GoTop()  { iter = datos.begin();}
	float  Next()   { float current = *iter; iter++; return current;}
	
       	
private:

    
	Data(const Data&);
	Data& operator=(const Data&);

	vector<float> datos;
	vector<float>::iterator iter;

protected:

	virtual bool SaveToFile(const char* nombre_file);
	virtual bool LoadFromFile(const char* nombre_file);

	
};
#endif