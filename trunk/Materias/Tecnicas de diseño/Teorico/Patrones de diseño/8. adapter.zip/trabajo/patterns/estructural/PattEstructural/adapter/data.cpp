/************************************************

  Data

************************************************/
#include <fstream>
#include <string>

#include "Data.h"

using namespace std;


Data::Data(const char* file)
{
   iter = datos.begin();

   LoadFromFile(file);

}
//-----------------------------------------------
bool Data::SaveToFile(const char* nombre_file)
{
   ofstream* file = new ofstream( nombre_file , ios_base::app | ios_base::binary);

   if(file->is_open()){
      
	   GoTop();
	   while(HasNext()){

	      *file << Next();
		  *file << "\n";
	   
	   }
	   file->close();
   }
   else{



   }
   delete file;
   return true;
}
//--------------------------------------
bool Data::LoadFromFile(const char* nombre_file)
{
   ifstream* file = new ifstream( nombre_file , ios_base::in | ios_base::binary);

   string datos_txt, aux_txt;

   if(file->is_open()){
      

	  while(!(*file).eof()){
      
		  getline(*file, aux_txt); 


		  // convertion datas
          float fdata = atof(aux_txt.c_str());
		  datos.push_back(fdata);
          
	  }

	   file->close();
	   
   }
   else{

      // exception

   }

    delete file;
  
   return true;
}