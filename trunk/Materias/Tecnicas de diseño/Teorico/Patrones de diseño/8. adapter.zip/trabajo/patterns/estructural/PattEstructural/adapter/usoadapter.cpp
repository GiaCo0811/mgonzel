// ESTRUCTURAL PATTERNS
/************************************************

     uso del pattern adapter


************************************************/

#include "docAdapter.h"

#include <iostream>

void main()
{
    DocumentoTexto documento_texto("c:\\trabajo\\patterns\\charlaDiego.txt");

    DocumentoData documento_datos("datos.dat");

	documento_texto.Print();

	char c;
    cin >> c;

	documento_datos.Print();
}