/*
 * MiObservable.java
 *
 * Created on September 7, 2002, 8:22 AM
 */

package model;
import java.util.*;
/**
 *
 * @author  guillermo pantaleo
 * @version 
 */
public class MiObservable extends Observable {
   
        public MiObservable(int grid){
           modelDatos = new int[grid][grid];
        }
        private int modelDatos[][];
        
        public int  getModelDato(int x, int y){ return modelDatos[x][y];}
        public void setModelDato(int x, int y, int dato){ modelDatos[x][y] = dato;}
        public void changeModelDato(int x, int y){ modelDatos[x][y] = 0 ;}
        
        
        public void notifyObservers(Object b) {
          // Otherwise it won't propagate changes:
           setChanged();
           super.notifyObservers(b);
        }
}
