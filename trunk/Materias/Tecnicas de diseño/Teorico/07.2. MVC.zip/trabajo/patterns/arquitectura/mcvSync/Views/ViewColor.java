
/**
 * Write a description of class ViewColor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
package Views;
import java.awt.*;
import java.util.*;
import model.*;
    
public class ViewColor extends View
{
    static final Color[] colors = { Color.white, Color.blue, Color.red, Color.black };
    Color cColor; 
    
  public void paintComponent(Graphics g) {    
    super.paintComponent(g);
    g.setColor(cColor);
    Dimension s = getSize();
    g.draw3DRect(0, 0, s.width, s.height, true);  
    
    /*super.paintComponent(g);
    Dimension s = getSize();
    g.setColor(Color.white);
    g.fillRect(0, 0, s.width, s.height);
    g.setColor(Color.black);
    g.setFont(new Font("helvetica", Font.BOLD, 12));
    g.drawString(Integer.toString(((MiObservable)notifier).getModelDato(x, y)), 10, 10);*/
  }
  
  
  Color newColor() {
      Color c = colors[0];
      if(notifier == null) return c;         
      return colors[((MiObservable)notifier).getModelDato(x, y)];
  }
  
  public ViewColor(int x, int y, Observable notifier) {
    super(x,y, notifier);
    cColor = newColor();    
  }
  
  public void updateView() {
        cColor = newColor();
        repaint();
  }
}
