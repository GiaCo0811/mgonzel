package Views;
/**
 * Write a description of class ViewTxt here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.awt.*;
import java.util.*;
import model.*;
    
public class ViewTxt extends View{
    public ViewTxt(int x, int y, Observable notifier){
        super(x,y,notifier);
    };
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Dimension s = getSize();
    g.setColor(Color.white);
    g.fillRect(0, 0, s.width, s.height);
    g.setColor(Color.black);
    g.setFont(new Font("helvetica", Font.BOLD, 12));
    g.drawString(Integer.toString(((MiObservable)notifier).getModelDato(x, y)), 10, 10);
  }
  public void updateView() {
        repaint();
  }
}    