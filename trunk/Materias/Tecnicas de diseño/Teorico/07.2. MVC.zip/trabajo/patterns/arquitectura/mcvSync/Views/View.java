package Views; 
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import model.*;
/**
 * Write a description of class View here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
 class View extends JPanel implements Observer { 
  protected Observable notifier;
  protected int x, y; // Locations in grid
      
  View(int x, int y, Observable notifier) {
    this.x = x;
    this.y = y;
    notifier.addObserver(this);
    this.notifier = notifier;
    addMouseListener(new ML());
  }
  public void updateView() {}
 
  // -------- CONTROLLER --------------
  protected class ML extends MouseAdapter { 
    public void mousePressed(MouseEvent e) {
      ((MiObservable)notifier).changeModelDato(x, y);
      notifier.notifyObservers(View.this); 
    }
  }
  //------------------------------------
  public void update(Observable o, Object arg) {
    View clicked = (View)arg;
    if(clicked.x == x && clicked.y == y) {
       updateView();
    }
  }
}
    