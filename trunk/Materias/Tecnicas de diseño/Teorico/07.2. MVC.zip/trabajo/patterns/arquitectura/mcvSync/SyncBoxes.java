
/**
 * Write a description of class SyncBoxes here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import model.*;
import javax.swing.*;
    
public class SyncBoxes extends JFrame
{
public static void main(String[] args) {
    int grid = 20;
    MiObservable notifier = new MiObservable(grid);
        
    for(int x = 0; x < grid; x++)
      for(int y = 0; y < grid; y++)
             notifier.setModelDato(x, y, (int)(Math.random() * 4));
        
    JFrame f = new BoxColor(grid,notifier);
    JFrame f2 = new BoxTxt(grid, notifier);
    
    f.setSize(500, 400);
    f.setVisible(true);
    f2.setSize(500, 400);
    f2.setVisible(true);
  
    // JDK 1.3:
    f.setDefaultCloseOperation(EXIT_ON_CLOSE);
    f2.setDefaultCloseOperation(EXIT_ON_CLOSE);
    // Add a WindowAdapter if you have JDK 1.2
}
    }
