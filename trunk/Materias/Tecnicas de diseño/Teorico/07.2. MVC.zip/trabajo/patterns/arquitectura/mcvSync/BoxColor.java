
/**
 * Write a description of class BoxColor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import model.*;
import Views.ViewColor;

    
public class BoxColor extends JFrame
{
 public BoxColor(int grid, MiObservable notifier) {
    
      setTitle("Model View Controller Pattern");
      Container cp = getContentPane();
      cp.setLayout(new GridLayout(grid, grid));
  
      // instancia datos
      for(int x = 0; x < grid; x++)
          for(int y = 0; y < grid; y++) {
             cp.add(new ViewColor(x, y, notifier)); // se crean los views             
          }
  }   
}
