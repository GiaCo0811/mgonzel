#!/bin/bash

sleepTimeCiclo=10
sleepTimeInvreci=10

function cleanup {
  waitOnInvreci
  exit 0
}

function waitOnInvreci {
  while [ -n "$(pgrep -n ^invreci$)" ]; do 
    sleep $sleepTimeInvreci
  done
}

function validarArchivo {
  archivo=$1
  
  #Chequeo que el formato del archivo es correcto
  if [ -n "$(echo $archivo | grep "^[0-9]\{8\}\.[0-9]\{8\}$")" ]; then
    
    fecha=${archivo##*.}

    #Comparo la fecha con la actual
    #se niega la comparacion porque se considera 0 = true
    return $(( !($fecha <= $(date +%Y%m%d)) ))

  fi

  return 1 
}

#setear traps para terminar el demonio
trap cleanup INT TERM

#bucle infinito
while true; do

  for archivo in $(ls $grupo/arribos/); do
    
    if validarArchivo $archivo
    then
      ./mover.sh "$grupo/arribos/$archivo" "$grupo/recibidos/$archivo" "invonio"

    else
      ./mover.sh "$grupo/arribos/$archivo" "$grupo/rechazados/$archivo" "invonio"

    fi

  done
  
  for archivo in $(ls $grupo/recibidos/); do
    waitOnInvreci
    ./invreci.sh 
  done

  sleep $sleepTimeCiclo

done
