#!/bin/bash

id=$(pgrep -n ^invonio.sh$)
if [ -n "$id" ]; then
  kill -TERM $id
  echo "Se detuvo el demonio de PID $id"
  exit 0
fi


