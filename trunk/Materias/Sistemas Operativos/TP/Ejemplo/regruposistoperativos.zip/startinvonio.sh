#!/bin/bash

#Chequear que no haya un invonio corriendo
pidInvonio=$(pgrep -n ^invonio.sh$)
if [ -n "$pidInvonio" ]; then
  echo "Invonio ya se esta ejecutando con PID $pidInvonio"
  exit 1
fi

#Chequear que el ambiente este correctamente iniciado
if [ "$CORRECTAMENTE_INICIALIZADO" != si ]; then
  echo "El ambiente no fue corrrectamente inicializado. Por favor ejecute invini."
  exit 2
fi

#lanzar invonio
./invonio.sh &
echo "Demonio ejecutandose con PID $(pgrep -n ^invonio.sh$)"
exit 0
