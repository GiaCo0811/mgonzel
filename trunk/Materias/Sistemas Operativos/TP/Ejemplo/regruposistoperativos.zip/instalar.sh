#!/bin/bash
#
# Instalador del programa
#
DATAFREE=""

function terminar {
	crearLog "Fin de Instalacion."
	exit $1
}

function emitir {
	echo $1
	./glog.sh "instalar" "$1"
}

function salidaError {
	echo $1
	./glog.sh "instalar" "$1" "E"
}

function crearLog {
	./glog.sh "instalar" "$1"
}


function iniciarLog {
	
	crearLog "Inicio de InstalacionA"
	emitir "Log de la instalacion: (`pwd`/instalar.log)"
	emitir "Nombre del directorio de configuracion: (`pwd`/conf)"
	emitir "Nombre del directorio de comandos: (`pwd`/comandos)"
	emitir "Nombre del directorio de logs: (`pwd`/comandos/log)"
	emitir "Nombre del directorio de pruebas: (`pwd`/prueba)"
	emitir "Nombre del directorio de ordenes de compra: (`pwd`/oc)"
	emitir "Nombre del directorio de ordenes de compra recibidas: (`pwd`/recibidos)"
	emitir "Nombre del directorio de ordenes de compra ya recibidas: (`pwd`/yarecibidos)"
	emitir "Nombre del directorio de ordenes de compra aceptadas: (`pwd`/aceptados)"
	emitir "Nombre del directorio de ordenes de compra rechazadas: (`pwd`/rechazados)"
	emitir "Nombre del directorio de arribo de ordenes de compra: (`pwd`/arribos)"
}

function aceptarInstalacion {
	echo "Proceso de Instalacion"
	echo "Esta seguro de que desea instalar este software?"
	out=0
	while [ $out -eq 0 ]
	do 
	read respuesta
		if [ "$respuesta" == "No" -o "$respuesta" == "no" -o "$respuesta" == "NO" -o "$respuesta" == "nO" ] 
		then
			emitir "Instalacion cancelada" 
 			out=1
		else
		if [ "$respuesta" == "Si" -o "$respuesta" == "si" -o "$respuesta" == "SI" -o "$respuesta" == "sI" ]
        	then
	   		out=1
        		else
	   			emitir "Debe responder (Si - No)"
        	fi
		fi
	done
	if [ "$respuesta" == "No" -o "$respuesta" == "no" -o "$respuesta" == "NO" -o "$respuesta" == "nO" ] 
	then
		exit 1
	fi
}

function detectarComponentesInstalados {
	
	if [ -e "$grupo/$CONFDIR/componentesInstalados.conf" ]
	then
	emitir "El programa ya fue instalado."

	emitir "Verificando componentes instalados..."
	a_IFS=$IFS
	IFS=$'\n'
		
	numgrupo=`grep 'NUMGRUPO' $grupo/$CONFDIR/componentesInstalados.conf | sed 's/.*=//'`

	if [ "$numgrupo" = "03" ]
	then

		comandosdir=`grep 'COMANDOSDIR' $grupo/$CONFDIR/componentesInstalados.conf | sed 's/.*=//'`

		emitir "\*        Proceso de Instalacion                              "
		emitir "\* Se encuentran instalados los siguientes componentes:       "
				
		if [ -f "$comandosdir/invini.sh" ]
		then
			emitir "\* INVINI "
		fi

		if [ -f "$comandosdir/startinvonio.sh" ]
		then
			emitir "\* STARTINVONIO "
		fi

		if [ -f "$comandosdir/stopinvonio.sh" ]
		then
			emitir "\* STOPINVONIO "
		fi

		if [ -f "$comandosdir/invonio.sh" ]
		then
			emitir "\* INVONIO "
		fi
	
		if [ -f "$comandosdir/invreci.sh" ]
		then
			emitir "\* INVRECI "
		fi

		if [ -f "$comandosdir/remioc.pl" ]
		then
			emitir "\* REMIOC "
		fi
	
		if [ -f "$comandosdir/occtrl.pl" ]
		then
			emitir "\* OCCTRL "
		fi				
	
		if [ -f "$comandosdir/mover.sh" ]
		then
			emitir "\* MOVER "
		fi

		emitir "\* Falta instalar los siguientes componentes:"

		if [ ! -f "$comandosdir/invini.sh" ]
		then
			emitir "\* INVINI "
		fi

		if [ ! -f "$comandosdir/startinvonio.sh" ]
		then
			emitir "\* STARTINVONIO "
		fi

		if [ ! -f "$comandosdir/stopinvonio.sh" ]
		then
			emitir "\* STOPINVONIO "
		fi

		if [ ! -f "$comandosdir/invonio.sh" ]
		then

			emitir "\* INVONIO "
		fi
	
		if [ ! -f "$comandosdir/invreci.sh" ]
		then
			emitir "\* INVRECI "
		fi

		if [ ! -f "$comandosdir/remioc.pl" ]
		then
			emitir "\* REMIOC "
		fi

		if [ ! -f "$comandosdir/occtrl.pl" ]
		then
			emitir "\* OCCTRL "
		fi
	
		if [ ! -f "$comandosdir/mover.sh" ]
		then
			emitir "\* MOVER "
		fi

	
		emitir "\* Elimine los componentes instalados e intentelo nuevamente."	
	
	
		emitir "\**************************************************************"
		emitir "Proceso de Instalacion Cancelado"
		exit 1
	fi	
	IFS=$a_IFS
	fi
	
}

#/********************************************************************************/


# MAIN
clear
#la existencia del archivo log la valida el glog
grupo=`pwd`
#export grupo

# 1.	Inicializar archivo de log
if [ ! -f ./glog.sh ]
then
	echo "No se encuentra el archivo glog.sh en el directorio de instalacion"
	echo "Fin de ejecucion."
	exit 1
fi
chmod a+x ./glog.sh
crearLog "Inicio de Ejecucion"

CONFDIR=conf
COMANDOSDIR=comandos
PRUEBADIR=prueba
OCDIR=oc
RECIBIDOSDIR=recibidos
ACEPTADOSDIR=aceptados
YARECIBIDOSDIR=yarecibidos
RECHAZADOSDIR=rechazados
ARRIBOSDIR=arribos
LOGDIR=comandos/log

# 2. Mostrar (y grabar en el log) donde se graba el log de la instalacion
emitir "Log de la instalacion: ($grupo/log/instalar.log)"

#3.  Mostrar (y grabar en el log) el nombre del directorio de parametros de configuracion
emitir "Nombre del directorio de configuracion: ($grupo/conf)"

# 4.Aceptacion de Instalacion
aceptarInstalacion

# 5. Detectar si el sistema o alguno de sus componentes ya esta instalado
detectarComponentesInstalados

# 6.	Loguear el nombre del directorio de ejecutables
crearLog "Log del directorio de ejecutables: COMANDOSDIR"

# 7.	Loguear el nombre del directorio para almacenar las oc
crearLog "Log del directorio de OC: OCDIR"

# 7.	Loguear el nombre del directorio para almacenar las oc
crearLog "Log del directorio de pruebas: PRUEBADIR"

# 8.	Definir directorio para los archivos de oc rechazados
crearLog "Log del directorio de OC rechazadas: RECHAZADOSDIR"

# 9.	Definir directorio para los archivos de arribos de oc
crearLog "Log del directorio de arribos de oc: ARRIBOSDIR"

# 10.	Definir directorio para los archivos de oc recibidos
crearLog "Log del directorio de oc recibidas: RECIBIDOSDIR"	

# 11.	Definir directorio para los archivos de oc ya recibidos
crearLog "Log del directorio de oc ya recibidos: YARECIBIDOSDIR"	

# 12.	Definir directorio para los archivos de oc aceptados
crearLog "Log del directorio de oc aceptadas: ACEPTADOSDIR"		

# 13.	Definir directorio para los archivos de log
crearLog "Log del directorio de archivos de log: LOGDIR"

# 14.   Mostrar estructura de directorios resultante y valores de parametros configurados
clear

emitir '\**************************************************************************'
emitir '\* Parametros de la Instalacion'
emitir '\**************************************************************************'
emitir "Nombre del directorio de configuracion: $grupo/$CONFDIR"
emitir "Nombre del directorio de ejecutables: $grupo/$COMANDOSDIR"
emitir  "Nombre del directorio de OC: $grupo/$OCDIR"
emitir  "Nombre del directorio de pruebas: $grupo/$PRUEBASDIR"
emitir  "Nombre del directorio de OC rechazadas: $grupo/$RECHAZADOSDIR"
emitir  "Nombre del directorio de arribo de OC: $grupo/$ARRIBOSDIR"
emitir  "Nombre del directorio de OC recibidos: $grupo/$RECIBIDOSDIR"
emitir  "Nombre del directorio de OC ya recibidos: $grupo/$YARECIBIDOSDIR"
emitir  "Nombre del directorio de OC aceptadas: $grupo/$ACEPTADOSDIR"	
emitir "Nombre del directorio de logs: $grupo/$LOGDIR"	
	
# 15.	Confirmar inicio de instalacion
emitir "Desea continuar? Si o No"
out1=0
while [ $out1 -eq 0 ]
do 
read respuesta1
	if [ "$respuesta1" == "No" -o "$respuesta1" == "no" -o "$respuesta1" == "NO" -o "$respuesta1" == "nO" ] 
	then
		emitir "Instalacion cancelada" 
		out1=1

	else
	if [ "$respuesta1" == "Si" -o "$respuesta1" == "si" -o "$respuesta1" == "SI" -o "$respuesta1" == "sI" ]
	then
   		out1=1
	else
   		emitir "Debe responder (Si- No)"
	fi
	fi
done
if [ "$respuesta1" == "No" -o "$respuesta1" == "no" -o "$respuesta1" == "NO" -o "$respuesta1" == "nO" ] 
then
	exit 1
fi


# 16.	Crear la estructura de Directorio definida
emitir "Creando Estructuras de Directorio......."

mkdir "$grupo/$COMANDOSDIR" 2> /dev/null
mkdir "$grupo/$CONFDIR" 2> /dev/null
mkdir "$grupo/$PRUEBADIR" 2> /dev/null
mkdir "$grupo/$OCDIR" 2> /dev/null
mkdir "$grupo/$RECHAZADOSDIR" 2> /dev/null
mkdir "$grupo/$ARRIBOSDIR" 2> /dev/null
mkdir "$grupo/$RECIBIDOSDIR" 2> /dev/null
mkdir "$grupo/$YARECIBIDOSDIR" 2> /dev/null
mkdir "$grupo/$ACEPTADOSDIR" 2> /dev/null
mkdir "$grupo/$LOGDIR" 2> /dev/null

sleep 1

# 17.	Instalacion
emitir "Moviendo Archivos..."
sleep 1

if [ ! -f "mover.sh" ]
then
emitir "No se ha instalado el componente MOVER. No existe el archivo mover.sh"
else
mv mover.sh $COMANDOSDIR/mover.sh
chmod a+x $COMANDOSDIR/mover.sh
emitir "Instalacion del componente MOVER completada"
fi
sleep 1

if [ ! -f "invini.sh" ]
then
emitir "No se ha instalado el componente INVINI. No existe el archivo invini.sh"
else
mv invini.sh $COMANDOSDIR/invini.sh
chmod a+x $COMANDOSDIR/invini.sh
emitir "Instalacion del componente INVINI completada"
fi
sleep 1

if [ ! -f "startinvonio.sh" ]
then
emitir "No se ha instalado el componente STARTINVONIO. No existe el archivo startinvonio.sh"
else
mv startinvonio.sh $COMANDOSDIR/startinvonio.sh
chmod a+x $COMANDOSDIR/startinvonio.sh
emitir "Instalacion del componente STARTINVONIO completada"
fi
sleep 1

if [ ! -f "stopinvonio.sh" ]
then
emitir "No se ha instalado el componente STOPINVONIO. No existe el archivo stopinvonio.sh"
else
mv stopinvonio.sh $COMANDOSDIR/stopinvonio.sh
chmod a+x $COMANDOSDIR/stopinvonio.sh
emitir "Instalacion del componente STOPINVONIO completada"
fi
sleep 1

if [ ! -f "invonio.sh" ]
then
emitir "No se ha instalado el componente INVONIO. No existe el archivo invonio.sh"
else
mv invonio.sh $COMANDOSDIR/invonio.sh
chmod a+x $COMANDOSDIR/invonio.sh
emitir "Instalacion del componente INVONIO completada"
fi
sleep 1

if [ ! -f "invreci.sh" ]
then
emitir "No se ha instalado el componente INVRECI. No existe el archivo invreci.sh"
else
mv invreci.sh $COMANDOSDIR/invreci.sh
chmod a+x $COMANDOSDIR/invreci.sh
emitir "Instalacion del componente INVRECI completada"
fi
sleep 1

if [ ! -f "occtrl.pl" ]
then
emitir "No se ha instalado el componente OCCTRL. No existe el archivo occtrl.pl"
else
mv occtrl.pl $COMANDOSDIR/occtrl.pl
chmod a+x $COMANDOSDIR/occtrl.pl
emitir "Instalacion del componente OCCTRL completada"
fi
sleep 1

if [ ! -f "remioc.pl" ]
then
emitir "No se ha instalado el componente REMIOC. No existe el archivo remioc.pl"
else
mv remioc.pl $COMANDOSDIR/remioc.pl
chmod a+x $COMANDOSDIR/remioc.pl
emitir "Instalacion del componente REMIOC completada"
fi
sleep 1

# 18.	Guardar la informacion de Instalacion
componentesInstaladosConf=$grupo/$CONFDIR/componentesInstalados.conf


emitir "FILECONF=\/conf\/componentesInstalados.conf" >> "$componentesInstaladosConf"
emitir "CONFDIR=$CONFDIR" >> "$componentesInstaladosConf"
emitir "LOGFILE=/log/instalar.log" >> "$componentesInstaladosConf"
emitir "COMANDOSDIR=$COMANDOSDIR" >>  "$componentesInstaladosConf"
emitir "OCDIR=$OCDIR" >> "$componentesInstaladosConf"
emitir "PRUEBADIR=$PRUEBADIR" >> "$componentesInstaladosConf"
emitir "RECIBIDOS1DIR=$RECIBIDOSDIR" >> "$componentesInstaladosConf"
emitir "RECHAZADOSDIR=$RECHAZADOSDIR" >> "$componentesInstaladosConf"
emitir "ARRIBOSDIR=$ARRIBOSDIR" >> "$componentesInstaladosConf"
emitir "YARECIBIDOSDIR=$YARECIBIDOSDIR" >> "$componentesInstaladosConf"
emitir "ACEPTADOSDIR=$ACEPTADOSDIR" >> "$componentesInstaladosConf"
emitir "LOGDIR=$LOGDIR" >> "$componentesInstaladosConf"
emitir "NUMGRUPO=03" >> "$componentesInstaladosConf"
emitir "GRUPO=grupo03" >> "$componentesInstaladosConf"
echo '' >> "$componentesInstaladosConf"

emitir "COMAND = INVINI" >> "$componentesInstaladosConf"
echo '' >> "$componentesInstaladosConf"
emitir "COMAND = STOPINVONIO" >> "$componentesInstaladosConf"
echo '' >> "$componentesInstaladosConf"
emitir "COMAND = STARTINVONIO" >> "$componentesInstaladosConf"
echo '' >> "$componentesInstaladosConf"
emitir "COMAND = INVONIO" >> "$componentesInstaladosConf"
echo '' >> "$componentesInstaladosConf"
emitir "COMAND = MOVER" >> "$componentesInstaladosConf"
echo '' >> "$componentesInstaladosConf"
emitir "COMAND = INVRECI" >> "$componentesInstaladosConf"
echo '' >> "$componentesInstaladosConf"
emitir "COMAND = REMIOC" >> "$componentesInstaladosConf"
echo '' >> "$componentesInstaladosConf"
emitir "COMAND = OCCTRL" >> "$componentesInstaladosConf"

# 19.	Mostrar mensaje indicando que fue lo que se instalo.
emitir "\************************************************************"
emitir "\* Se encuentran instalados los siguientes componentes:	   "
if [ -f "$COMANDOSDIR/mover.sh" ]
then
	emitir "\* MOVER                                                   "
fi
if [ -f "$COMANDOSDIR/startinvonio.sh" ]
then
	emitir "\* STARTINVONIO                                                 " 
fi
if [ -f "$COMANDOSDIR/stopinvonio.sh" ]
then
emitir "\* STOPINVONIO                                                 "  
fi
if [ -f "$COMANDOSDIR/invonio.sh" ]
then
emitir "\* INVONIO                                                 "
fi
if [ -f "$COMANDOSDIR/invreci.sh" ]
then
emitir "\* INVRECI                                                 "
fi
if [ -f "$COMANDOSDIR/occtrl.pl" ]
then
emitir "\* OCCTRL                                                  "
fi
if [ -f "$COMANDOSDIR/remioc.pl" ]
then
emitir "\* REMIOC                                                  "
fi
if [ -f "$COMANDOSDIR/invini.sh" ]
then
emitir "\* INVINI                                                  "
fi
emitir "\************************************************************"


# 20.Cerrar el archivo de log

crearLog "Fin de ejecucion."

mv ./glog.sh "$COMANDOSDIR/glog.sh"
chmod a+x "$COMANDOSDIR/glog.sh"

