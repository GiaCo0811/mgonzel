#!/bin/bash

# Funcionalidad
# Escribe en el archivo cuyo nombre es obtenido automaticamente en base al
# nombre del comando, alojado en $LOGDIR.
#
# Parametros: Nombre del comando (requerido), Mensaje (requerido), Tipo de mensaje (opcional, valor por defecto = I)
#
# Codigos de error: 1 Cantidad erronea de argumentos; 2 Tipo de mensaje equivocado; 3 No se puede crear el directorio de logs; 4 No se definio la variable de ambiente $LOGDIR;
#
# Hipotesis:
#	1 La fecha se guarda como YYYY/mm/dd HH:MM:SS

# Verifico la cantidad de argumentos
if [ $# -lt 2 ]
then
	echo 'Error#1: Cantidad erronea de argumentos.'
	exit 1;
fi

# Seteo el valor por defecto para el parametro opcional
if [ $# -eq 3 ]
then
	codigoMensaje=$3
else
	codigoMensaje='I'
fi

# Obtengo el tipo de mensaje a registrar
case $codigoMensaje in
	'I') tipoMensaje='INFORMATIVO';;
	'W') tipoMensaje='WARNING';;
	'E') tipoMensaje='ERROR';;
	'SE') tipoMensaje='ERROR SEVERO';;
	*) echo 'Error#2: Tipo de mensaje equivocado.'; exit 2;;
esac

# Genero el registro...
# El registro contiene: fecha y hora - tipo: Mensaje
fechaHora=`date +'%Y/%m/%d %T'`
registro="$fechaHora-$tipoMensaje-$2"

# Preparo el archivo...
# Si se ejecuta desde el comando INSTALAR, toma por defecto el directorio "."
CMD_INSTALAR="instalar"
if [ "$1" = "$CMD_INSTALAR" ]
then
	LOGDIR='.'
else
	if [ -z "$LOGDIR" ]
	then
		echo 'Error#4: No se definio la variable de ambiente $LOGDIR.'
		exit 4
	fi

	# Si no existe el directorio de logs, lo creo
	mkdir -p $grupo/$LOGDIR

	if [ $? -ne 0 ]
	then
		echo 'Error#3: No se puede crear el directorio de logs.'
		exit 3
	fi
fi


# El nombre del archivo es el del comando, terminado en .log, y su direccion es
# la establecida por la variable de ambiente $LOGDIR
archivo=$grupo/$LOGDIR/$1.log

# Aniado al final del archivo, creandolo si no existe.
echo $registro >> $archivo

