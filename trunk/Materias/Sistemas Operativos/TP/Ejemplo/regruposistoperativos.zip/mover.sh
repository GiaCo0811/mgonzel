#!/bin/bash

# Funcionalidad 
# Mueve el archivo desde la ubicacion origen a la ubicacion destino. En el caso
# que el archivo ya exista en la ruta destino, se crea un subdirectorio /dup
# donde se coloca el mismo, concatenandole a su nombre un punto y un numero
# de 3 digitos que se asigna en forma secuencial.

# Parametros: Ruta origen del archivo (requerido); Ruta destino del archivo (requerido); Comando invocante (opcional, valor por defecto = MOVER)
#
# Codigos de error: 1 Cantidad erronea de argumentos; 2 No existe el archivo a mover
#
# Hipotesis:
#       1 Si no se pasa el comando, se toma por defecto el comando MOVER y se graba en su log
#       2 La fecha se guarda como YYYY/mm/dd HH:MM:SS
#	3 En caso de archivo duplicado trabajo con numero de secuencia descentralizado.

if [ $# -lt 2 ]
   then
	./glog.sh "MOVER" "Cantidad incorrecta de parametros" "E"
	exit 1	
fi

if [ ! -z $3 ]
   then
	Comando=$3
   else
	Comando="MOVER"
fi

# Verifico si el origen y el destino son iguales; en ese caso no hago nada
if [ "$1" != "$2" ]
   then
       # Verifico que el archivo a mover exista
       if [ -f "$1" ]
	  then
	      # Verifico si se trata de un archivo duplicado en el directorio destino
		if [ -f "$2" ]
		   then
		       dir=${2%/*}
		       nomArchivo=${2##*/}
		       # Verifico la existencia del subdirectorio /dup en el directorio destino
		       if [ ! -d "$dir/dup" ]
			  then
		 	      # Si no existe, crear el subdirectorio
		 	      mkdir "$dir/dup"			
		       fi 
		       # Mover el archivo con el nombre <nombre del archivo>.nnn al subdirectorio /dup
		       # Obtengo el proximo numero disponible
		       version=0
		       for i in `ls "$dir/dup/$nomArchivo."* 2> /dev/null`			
			  do
			     if [ $version -lt ${i##*.} ]
				then
				    version=${i##*.}
			     fi
		        done
			version=`expr $version + 1`
			cCifras=${#version}
			# Obtengo la cantidad de ceros para darle formato a la extension del archivo
			while [ $cCifras -lt 3 ]
			  do
			     nCeros="0$nCeros"
			     cCifras=`expr $cCifras + 1` 
			  done
			version=$nCeros$version
		 	mv "$1" "$dir/dup/$nomArchivo.$version"
			./glog.sh $Comando "El archivo duplicado $1 fue movido a $dir/dup/$nomArchivo.$version" "W"			
		   else			
		        mv "$1" "$2"			
			./glog.sh $Comando "El archivo $1 fue movido a $2" "I"
		fi 
       else
	    ./glog.sh $Comando "El archivo $1 que desea mover no existe" "E"
            exit 2
       fi 
fi 
exit 0
