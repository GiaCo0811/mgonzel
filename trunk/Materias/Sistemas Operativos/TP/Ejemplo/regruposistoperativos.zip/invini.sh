#! /bin/bash

# Funcionalidad
# Inicializa el ambiente y sus variables. Valida la existencia de los archivos necesarios para el funcionamiento del sistema.
# Si todo es correcto setea las variables de ambiente e inicia el demonio.
#
# Parametros: Ninguno
#
# Codigos de error: 0 Ejecucion correcta del script; 1 Faltan instalacion de componentes; 2 Faltan archivos esenciales ocgob y ocdet ; 3 No se pudo lanzar #		    el demonio; 
#
# Hipotesis:
#	1 Se debe haber ejecutado el script de instalacion


clear

userDir=`pwd`

# Agrego al PATH el directorio de trabajo
PATH=$PATH:$grupo

#Chequeo que invini no haya sido ejecutado o si el ambiente no ha sido correctamente inicializado
if [ -z "$CORRECTAMENTE_INICIALIZADO" -o "$CORRECTAMENTE_INICIALIZADO" = "no" ]
then
    # Definicion de variables de ambiente    
	export grupo=${userDir%/*}
	export COMANDOSDIR=${userDir}    
	export LOGDIR=`grep LOGDIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`
	export PRUEBADIR=`grep PRUEBADIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`
	export OCDIR=`grep OCDIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`
	export RECIBIDOSDIR=`grep RECIBIDOS1DIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`
	export RECHAZADOSDIR=`grep RECHAZADOSDIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`
	export ARRIBOSDIR=`grep ARRIBOSDIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`
	export YARECIBIDOSDIR=`grep YARECIBIDOSDIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`
	export ACEPTADOSDIR=`grep ACEPTADOSDIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`
	export CONFDIR=`grep CONFDIR $grupo/conf/componentesInstalados.conf|sed 's/.*=//'`

	echo "Preparando entorno de ejecucion."
fi

#Verifico si estan instalados todos los componentes
componentesInstaladosExiste=`find $grupo/$CONFDIR -name componentesInstalados.conf`
if [ -z "$componentesInstaladosExiste" ]
then
    echo ""
    echo "Inicializacion de Ambiente No fue exitosa. La instalacion esta incompleta, alguno de los componentes del sistema no fue instalado."    
    export CORRECTAMENTE_INICIALIZADO="no"
    return 1
fi


#Verifico que exista el archivo a utilizar
existeA1=`find $grupo/$OCDIR -name "ocgob*"`
#existeA1=1
#Verifico que exista el archivo a utilizar
existeA2=`find $grupo/$OCDIR -name "ocdet*"`
#existeA2=1
if [ -z "$existeA1" -o -z "$existeA2" ]
then
	if [ -z "$existeA1"]
	then
	    echo ""
	    echo "No se puede inicializar el ambiente, no se pueden localizar el archivo ocgob indispensable para ejecutar el sistema."
	fi
	if [ -z "$existeA2"]
	then
            echo ""
	    echo "No se puede inicializar el ambiente, no se pueden localizar el archivo ocdet indispensable para ejecutar el sistema."
	fi
	    echo ""
	    echo "Inicializacion de Ambiente No fue exitosa."
	
	export CORRECTAMENTE_INICIALIZADO="no"
	return 2
fi

# Imprimo variables de ambiente
echo ""
if [ -z "$CORRECTAMENTE_INICIALIZADO" -o "$CORRECTAMENTE_INICIALIZADO" = "no" ]
then
echo ""
echo "Inicializacion de Ambiente Concluida."
else
echo ""
echo "El ambiente ya se encontraba inicializado."
fi
echo ""
echo "Ambiente:"
echo "GRUPO    =  $grupo"
echo "COMANDOSDIR   =  $COMANDOSDIR" 
echo "LOGDIR   =  $LOGDIR"
echo "PRUEBADIR   =  $PRUEBADIR" 
echo "OCDIR  =  $OCDIR" 
echo "RECIBIDOSDIR   =  $RECIBIDOSDIR"
echo "RECHAZADOSDIR   =  $RECHAZADOSDIR"
echo "ARRIBOSDIR   =  $ARRIBOSDIR"
echo "YARECIBIDOSDIR =  $YARECIBIDOSDIR" 
echo "ACEPTADOSDIR  =  $ACEPTADOSDIR"  
echo "CONFDIR  =  $CONFDIR"  
export CORRECTAMENTE_INICIALIZADO="si"
echo "CORRECTAMENTE_INICIALIZADO = $CORRECTAMENTE_INICIALIZADO"

invonioid=`ps --no-heading -o pid -C "invonio.sh"`

if [ -z "$invonioid" ]
then
   #Si invonio.sh no esta activo 
  # Ejecuto demonio INVONIO en background
  echo ""	
  echo "Activando invonio.sh."  
  ./startinvonio.sh		  
else
	echo ""
	echo "Comando INVONIO ya estaba funcionando."
fi

invonioid=`ps --no-heading -o pid -C "invonio.sh"`

if [ -z "$invonioid" ]
then
	echo ""
	echo "No se pudo activar invonio.sh"
	export CORRECTAMENTE_INICIALIZADO="no"
	return 3
else 
	echo ""
	echo "Demonio corriendo bajo el no.: $invonioid."
fi

return 0
