//: PerfectTime.java

// Implementacion del objeto remoto
import java.rmi.*;
import java.rmi.server.*;



public class PerfectTime extends UnicastRemoteObject
                         implements PerfectTimeI {
  // por serializable
  private static final long serialVersionUID = 0;
  
  // Implementation of the interface:
  public long getPerfectTime() throws RemoteException {
    return System.currentTimeMillis();
  }
  // Must implement constructor to throw
  // RemoteException:
  public PerfectTime() throws RemoteException { }
   
  // Registration for RMI serving:
  public static void main(String[] args) {
    System.setSecurityManager(new RMISecurityManager());
    try {
      PerfectTime pt = new PerfectTime();
      Naming.bind("rmi://IPantaleog2/PerfectTime", pt);
          
      System.out.println("Listo para proveer la hora");
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
} 