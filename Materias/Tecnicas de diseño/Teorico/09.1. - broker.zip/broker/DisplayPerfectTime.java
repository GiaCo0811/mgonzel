//: DisplayPerfectTime.java
// Muestra el uso de un objeto remoto

import java.rmi.*;
//import java.rmi.registry.*;
import java.util.*;


public class DisplayPerfectTime {
  public static void main(String[] args) {
    System.setSecurityManager(new RMISecurityManager());
    try {
      PerfectTimeI t = (PerfectTimeI)Naming.lookup("rmi://IPantaleog2/PerfectTime");
      for(int i = 0; i < 10; i++) {
          
          System.out.println("Hora del Server = " + t.getPerfectTime());
      
          Date d  = new Date();
          d.setTime(t.getPerfectTime());
          System.out.println(d.toString() + "\n");  
          
          Thread.sleep(2000);
      }
       
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
} 