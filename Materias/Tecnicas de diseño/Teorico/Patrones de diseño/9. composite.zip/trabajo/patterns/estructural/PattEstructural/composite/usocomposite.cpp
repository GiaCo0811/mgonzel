/************************************************

     uso del pattern composite


     guillermo pantaleo 2/2/2002

************************************************/
#include "composite.h"
#include <iostream>
#include <fstream>


using namespace std; 

bool ReadFile(const char* name_file, string& txt_file)
{

  ComposedException exc("Errores al leer el file !!! \n");

  ifstream* file = new std::ifstream( name_file, std::ios_base::in);
  
  if(file->is_open()){
	  

      // leo el file
      char c;
	  while(file->get(c)){
		   
		   txt_file += c;

	  }

      // mido longitud del file
      if(txt_file.length() < 100) {

          exc.Add(new MiException("File corrupto : logitud < 100 caracteres"));
      }

      // detecto encabezamiento
      string::size_type i = 0;
      if(txt_file.find("123@begin", i) == string::npos) {

           exc.Add(new MiException("File corrupto : patron '123@begin' no detectado"));
      }

      // detecto cola
      i = 0;
      if(txt_file.find("123@end", i) == string::npos) {

           exc.Add(new MiException("File corrupto : patron '123@end' no detectado"));
      }
  }
  else{
	  
	  exc.Add(new MiException("No se puede abrir el file"));
	  file->close();

  }

  if(exc.HasExceptions()) throw exc;

  return true;
}

//-------------------------------------------

void main()
{

	string txt_file;

	try{

       ReadFile("c:\\trabajo\\patterns\\data.dat", txt_file);
	   cout << "Mensaje recibido: " << endl << endl;
       cout << txt_file.c_str() << endl << endl;

	}
	catch(MiException& exc){

		cout << exc.what() << "\n";

		if( exc.getComposite()){  // is composite

           exc.GoTop();
		   while(exc.HasNext()){
        
		    	exception* current = exc.Next();
			    cout << current->what() << "\n";

		   }
		}
		
  	}
    catch(...){

		cout << "Exception desconocida !!!" << "\n";
	}
}