/*************************************************
  COMPOSITE

  declaracion de las clases que forman los elementos
  unitarios y el composite

  guillermo pantaleo 2/2/2002

**************************************************/
#ifndef COMPOSITE_H_
#define COMPOSITE_H_

#include <stdexcept>
#include <list>
#include <algorithm>
#include <functional>

using namespace std;


//------------- helper struct --------------------
template<typename T>
struct DeleteObject: public unary_function<const T*, void>{

	void operator()(const T* ptr) const{
     
		delete ptr;

	}
};

// ---------- composite declaration --------------
class MiException;
class ComposedException;

typedef list<MiException*> CExceptions;
typedef CExceptions::iterator CExceptionsIter;

class MiException : public exception{

public:

	MiException(){}
	MiException(const char* s):exception(s){}
	MiException(const MiException& rh):exception(rh){} //completar
    virtual ~MiException(){}

	// composite protocol
	virtual ComposedException* getComposite(){ return 0;}
	virtual Add(MiException*){}
	virtual Remove(MiException*){}
	virtual bool HasExceptions(){ return true;}

	virtual void GoTop(){ }
	virtual bool HasNext(){ return false;}
	virtual MiException* Next(){ return 0;}

};
//---------------------------------
class ComposedException : public MiException
{

public :

	ComposedException(){ list_iter = the_exceptions.begin();}

    ComposedException(const char* s):MiException(s){list_iter = the_exceptions.begin();}

	ComposedException(ComposedException&);

	virtual ~ComposedException(){ 
		                                for_each(the_exceptions.begin(),
		                                         the_exceptions.end(),
										         DeleteObject<exception>());
	      						}
	// composite protocol
    ComposedException* getComposite(){ return this;}
	virtual Add(MiException* exc)    { the_exceptions.push_back(exc);}
	virtual Remove(MiException* exc) { the_exceptions.remove(exc);}
	virtual bool HasExceptions(){ return the_exceptions.size() > 0;}

    // the_exceptions handling 
	void GoTop(){ list_iter = the_exceptions.begin();}
	bool HasNext(){ return list_iter != the_exceptions.end();}
	MiException* Next(){ MiException* current = *list_iter; list_iter++; return current; }

private:

     CExceptions      the_exceptions;
	 CExceptionsIter  list_iter;

};
//--------------------------------------
inline ComposedException::ComposedException( ComposedException& rh):MiException(rh)
{

	CExceptionsIter itr = rh.the_exceptions.begin();
	while(itr != rh.the_exceptions.end()){
  
		the_exceptions.push_back(new MiException(**itr));
		itr++;

	}
   
	list_iter = the_exceptions.begin();
}

#endif