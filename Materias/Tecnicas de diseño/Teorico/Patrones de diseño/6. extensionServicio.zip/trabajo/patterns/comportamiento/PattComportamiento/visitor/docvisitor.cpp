/************************************************
   Implementacion del pattern VISITOR

************************************************/
#include "docvisitor.h"
#include "documento.h"

DocumentoTextoVisitor::DocumentoTextoVisitor()
:count_palabras(0)
{

	// prepara las palabras claves
	palabras_claves.push_back("objeto");
	palabras_claves.push_back("clase");
   
}
//-----------------------------------------------
void DocumentoTextoVisitor::Visit(Documento& doc)
{
	string texto_doc = doc.GetElTexto();

	// se procesa el texto
	list<string>::iterator  iter_palabras = palabras_claves.begin();
	while(iter_palabras != palabras_claves.end()){

	   string::size_type i = 0;
      
	   while((i = texto_doc.find(*iter_palabras, i)) != string::npos){

		   if(i != string::npos){
	   
			   count_palabras++;
			   i++;
		   }
		   
	   }

	   ++iter_palabras;
	}
}
//************************************************
DocumentoNroVisitor::DocumentoNroVisitor()
:count_total(0)
{
   
}
//-----------------------------------------------
void DocumentoNroVisitor::Visit(Documento& doc)
{
	vector<double> datos = doc.GetDatos();

	// se procesa el texto
	vector<double>::iterator  iter = datos.begin();
	while(iter != datos.end()){

           count_total += *iter;
	  	   ++iter;
	}
}