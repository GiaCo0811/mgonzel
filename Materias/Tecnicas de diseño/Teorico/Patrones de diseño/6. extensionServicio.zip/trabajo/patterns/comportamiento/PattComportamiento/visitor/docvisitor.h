//-----------------------------------------------
// Pattern VISITOR
//-----------------------------------------------
#ifndef DOCVISITOR_H_
#define DOCVISITOR_H_

#pragma warning ( disable : 4786 )

#include <iostream>
#include <list>

using namespace std;

class Documento;

class DocumentoVisitor
{

public:

   
	virtual void Visit(Documento&) = 0;
	

private:
	
};
//-----------------------------------------------------
class DocumentoTextoVisitor : public DocumentoVisitor
{

public:

	DocumentoTextoVisitor();

	virtual void Visit(Documento&);
	
	void PrintTotal()   { cout << "VISITOR - Total palabras buscadas: " << count_palabras << endl << endl;}

private:
	int count_palabras;
	list<string> palabras_claves;
};
//---------------------------------------
class DocumentoNroVisitor : public DocumentoVisitor
{

public:

	DocumentoNroVisitor();

	virtual void Visit(Documento&);
	
	void PrintTotal()   { cout << "VISITOR - Total numerico: " << count_total << endl << endl;}

private:
	int count_total;
	
};
#endif