//-----------------------------------------------
//     Class composed for acyclic visitor
//-----------------------------------------------
#ifndef DOCTXTVISITOR_H_
#define DOCTXTVISITOR_H_

#pragma warning ( disable : 4786 )

#include "elementvisitor.h"
#include "txtvisitor.h"
#include <iostream>
#include <list>

using namespace std;


class DocTxtVisitor : public ElementVisitor, public TxtVisitor
{

public:

	DocTxtVisitor();

	void VisitTexto(Documento&); 

	void PrintTotal()   { cout << "VISITOR ACICLICO - Total palabras buscadas: " << count_palabras << endl << endl;}

private:
	int count_palabras;
	list<string> palabras_claves;
};
#endif