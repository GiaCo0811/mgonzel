//-----------------------------------------------
//        Acyclic  Visitor
//-----------------------------------------------

#ifndef ELEMENTVISITOR_H_
#define ELEMENTVISITOR_H_

class ElementVisitor
{

public:
	virtual ~ElementVisitor(){}
};
#endif