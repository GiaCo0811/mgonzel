/************************************************

  DocumentoNumeroImpl

 
************************************************/
#include "DocumentoNumeroImpl.h"
#include <iostream>
#include <fstream>
#include <string>

#include <valarray>
#include <algorithm>


using namespace std;


DocumentoNumeroImpl::DocumentoNumeroImpl(const char* file): DocumentoImpl(file)
{
	LoadFromFile(file);
}
//--------------------------------------
DocumentoNumeroImpl::~DocumentoNumeroImpl()
{
}
//--------------------------------------
bool DocumentoNumeroImpl::PrintContenido()
{


  if(GetElBuffer().size() == 0){
       
      LoadFromFile(GetNombreFile().c_str());

   }
 

   //cout << GetElBuffer().c_str() << "\n";

   vector<double>::iterator it = datos.begin();
   while(it != datos.end()){

     cout << "dato : "<< *it << endl;
     it++;

   }

   return true;
}
//--------------------------------------
bool DocumentoNumeroImpl::SaveToFile(const char* nombre_file)
{
   ofstream* file = new ofstream( nombre_file , ios_base::app);

   if(file->is_open()){
      
	   *file << GetElBuffer().c_str();
	   file->close();
	   
   }
   else{

      // excepcion

   }
   delete file;
   return true;
}
//--------------------------------------
bool DocumentoNumeroImpl::LoadFromFile(const char* nombre_file)
{
   ifstream* file = new ifstream( nombre_file , ios_base::in);

   if(file->is_open()){
      
	   char c;
	   while(file->get(c)){
		   
		   GetElBuffer() += c;

	   }
	   

      // *file >> el_texto; // para en los blancos ????

	   file->close();
	   
   }
   else{

       // excepcion

   }

   // convierto a numeros (double) y lleno el vector
   std::string::size_type i = 0;
   std::string::size_type j = 0;

   while ((j = GetElBuffer().find(";", i)) != std::string::npos) {
      
     if (j == std::string::npos) {
         --j;
         
         string s = GetElBuffer().substr(i, j);
         double valor = atof(s.c_str());
         datos.push_back(valor);
         
         break;
      }

      string s = GetElBuffer().substr(i, j  - i);
      double valor = atof(s.c_str());
      datos.push_back(valor);
      
      j++;
      i = j;
   }


   delete file;
   return true;
}
//-----------------------------------------------
bool lessthan(double d1, double d2) {

   return d1<d2;
}
bool greaterthan(double d1, double d2) {

   return d1>d2;
}
string DocumentoNumeroImpl::GetOrdenCreciente()
{
   string s;
   
   sort(datos.begin(), datos.end(), lessthan);

   vector<double>::iterator it = datos.begin();
   while(it != datos.end()){

      char dummy[20];
      sprintf(dummy, "%f", *it);
      s += dummy;
      s += "\n";
     
      it++;

   }
   
   return s;
}

string DocumentoNumeroImpl::GetOrdenDecreciente()
{

	string s;

   sort(datos.begin(), datos.end(), greaterthan);

   vector<double>::iterator it = datos.begin();
   while(it != datos.end()){

      char dummy[20];
      sprintf(dummy, "%f", *it);
      s += dummy;
      s += "\n";
     
      it++;

   }

	return s;
}

string DocumentoNumeroImpl::Maximo()
{
   
	string s;

   vector<double>::iterator it = datos.begin();
  
   valarray<double> valarray_datos(it, datos.size());

   double db = valarray_datos.max();

   char dummy[20];
   sprintf(dummy, "%f", db);
   s = dummy;

	return s;
}

string DocumentoNumeroImpl::Minimo()
{
   
	string s;

   vector<double>::iterator it = datos.begin();
  
   valarray<double> valarray_datos(it, datos.size());

   double db = valarray_datos.min();

   char dummy[20];
   sprintf(dummy, "%f", db);
   s = dummy;

	return s;
}