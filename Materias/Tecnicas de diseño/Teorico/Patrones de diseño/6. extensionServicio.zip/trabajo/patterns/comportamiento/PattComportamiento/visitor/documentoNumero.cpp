/************************************************

  DocumentoNumerico

************************************************/
#include <iostream>
#include <fstream>

#include <valarray>
#include <algorithm>

#include "DocumentoNumero.h"

#include "docvisitor.h"
#include "docnrovisitor.h"

using namespace std;


DocumentoNumerico::DocumentoNumerico(const char* file):Documento(file)
{
   LoadFromFile(file);
}
//-----------------------------------------------
DocumentoNumerico::~DocumentoNumerico()
{
}
//--------------------------------------
bool DocumentoNumerico::SaveToFile(const char* nombre_file)
{
   ofstream* file = new ofstream( nombre_file , ios_base::app);

   if(file->is_open()){
      
	   *file << el_texto.c_str();
        file->close();
	   
   }
   else{

      // excepcion

   }
   delete file;
   return true;
}
//--------------------------------------
bool DocumentoNumerico::LoadFromFile(const char* nombre_file)
{
   ifstream* file = new ifstream( nombre_file , ios_base::in);

   if(file->is_open()){
      
	   char c;
	   while(file->get(c)){
		   
		   el_texto += c;

	   }
	   

      // *file >> el_texto; // para en los blancos ????

	   file->close();
	   
   }
   else{

       // excepcion

   }

   // convierto a numeros (double) y lleno el vector
   std::string::size_type i = 0;
   std::string::size_type j = 0;

   while ((j = el_texto.find(";", i)) != std::string::npos) {
      
     if (j == std::string::npos) {
         --j;
         
         string s = el_texto.substr(i, j);
         double valor = atof(s.c_str());
         datos.push_back(valor);
         
         break;
      }

      string s = el_texto.substr(i, j  - i);
      double valor = atof(s.c_str());
      datos.push_back(valor);
      
      j++;
      i = j;
   }


   delete file;
   return true;
}
//-----------------------------------------------
bool DocumentoNumerico::Print()
{
   if(el_texto.size() == 0){
       
      LoadFromFile(nombre_file.c_str());

   }
 

   //cout << GetElBuffer().c_str() << "\n";

   vector<double>::iterator it = datos.begin();
   while(it != datos.end()){

     cout << "dato : "<< *it << endl;
     it++;

   }

   return true;
}
//-----------------------------------------------
void DocumentoNumerico::Accept(DocumentoVisitor& doc)
{
	doc.Visit(*this);
}
//-----------------------------------------------
void DocumentoNumerico::Accept(ElementVisitor& doc)
{

	if(DocNroVisitor* p = dynamic_cast<DocNroVisitor*>(&doc)){

		p->VisitNumero(*this);
	}

}