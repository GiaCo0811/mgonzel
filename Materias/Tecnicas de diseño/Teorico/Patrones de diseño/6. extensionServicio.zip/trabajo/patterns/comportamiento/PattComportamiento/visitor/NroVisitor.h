//-----------------------------------------------
//     Class visitor for acyclic visitor
//-----------------------------------------------
#ifndef NROVISITOR_H_
#define NROVISITOR_H_

#pragma warning ( disable : 4786 )

class Documento;

class NroVisitor
{

public:
	
	virtual void VisitNumero(Documento&) = 0; 

};
#endif