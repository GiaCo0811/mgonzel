/************************************************

  DocumentoNumeroImpl 
  este es la declaracion de la clase que modela
  un DocumentoNumeroImpl de texto, usada como ejemplo para
  el pattern Bridge

*************************************************/
#ifndef DOCUMENTONUMEROIMPL_H_
#define DOCUMENTONUMEROIMPL_H_

#include"documentoImpl.h"

#include <string>
#include <vector>

using namespace std;

class DocumentoNumeroImpl : public DocumentoImpl
{


public:

	DocumentoNumeroImpl(const char* nombre_file);
	
	virtual ~DocumentoNumeroImpl();

	
	// manejo del texto contenido
	string& GetContenido()        { return GetElBuffer();}
	void    SetContenido(string& s){ SetElBuffer(s);}
	bool    PrintContenido();
    
	string  GetOrdenCreciente();
	string  GetOrdenDecreciente();
   string  Maximo();
	string  Minimo();

   
	string  FiltraTexto(string s){ return "";}
	string  TextoEnMayusculas() {  return "";}
	string  TextoEnMinusculas() {  return "";}

   DocumentoImpl* Clone() {return new DocumentoNumeroImpl(*this);}

	
private:

    
	
	DocumentoNumeroImpl& operator=(const DocumentoNumeroImpl&);

   vector<double> datos;

protected:

   DocumentoNumeroImpl(const DocumentoNumeroImpl& rd):DocumentoImpl(rd){ datos = rd.datos;}

	// manejo del file
	virtual bool SaveToFile(const char* nombre_file);
	virtual bool LoadFromFile(const char* nombre_file);

	
};
#endif