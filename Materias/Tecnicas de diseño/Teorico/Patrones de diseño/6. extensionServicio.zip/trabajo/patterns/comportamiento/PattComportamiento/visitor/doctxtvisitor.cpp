/************************************************
   Implementacion del pattern acyclic VISITOR

************************************************/
#include "doctxtvisitor.h"
#include "documento.h"

DocTxtVisitor::DocTxtVisitor()
:count_palabras(0)
{

	// prepara las palabras claves
	palabras_claves.push_back("objeto");
	palabras_claves.push_back("clase");
   
}
//-----------------------------------------------
void DocTxtVisitor::VisitTexto(Documento& doc)
{
	string texto_doc = doc.GetElTexto();

	// se procesa el texto
	list<string>::iterator  iter_palabras = palabras_claves.begin();
	while(iter_palabras != palabras_claves.end()){

	   string::size_type i = 0;
      
	   while((i = texto_doc.find(*iter_palabras, i)) != string::npos){

		   if(i != string::npos){
	   
			   count_palabras++;
			   i++;
		   }
		   
	   }

	   ++iter_palabras;
	}
}
