/************************************************

   uso del Pattern Visitor
  
*************************************************/
#include "documentoTexto.h"
#include "docvisitor.h"
#include "doctxtvisitor.h"

#include "documentoNumero.h"
#include "nrovisitor.h"
#include "docnrovisitor.h"

#include <iostream>
using namespace std;

void main()
{

    // documento de texto
	DocumentoTexto DocumentoTXT("c:\\trabajo\\patterns\\charlaDiego.txt");

	DocumentoTXT.Print();

	char c;
    cin >> c;

	DocumentoTextoVisitor doc_visit;
	DocumentoTXT.Accept(doc_visit);
    doc_visit.PrintTotal();
   

    cin >> c;

	DocTxtVisitor txt_acyclic_visitor;
	DocumentoTXT.Accept(txt_acyclic_visitor);
	txt_acyclic_visitor.PrintTotal();

    cin >> c;

    // documento numerico --------------------
    DocumentoNumerico DocumentoNRO("c:\\trabajo\\patterns\\datos.txt");

	DocumentoNRO.Print();

	cin >> c;

	DocumentoNroVisitor nro_visit;
	DocumentoNRO.Accept(nro_visit);
    nro_visit.PrintTotal();
   

    cin >> c;

	DocNroVisitor nro_acyclic_visitor;
	DocumentoNRO.Accept(nro_acyclic_visitor);
	nro_acyclic_visitor.PrintTotal();

}