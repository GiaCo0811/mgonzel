//-----------------------------------------------
//     Class visitor for acyclic visitor
//-----------------------------------------------
#ifndef TXTVISITOR_H_
#define TXTVISITOR_H_

#pragma warning ( disable : 4786 )

class Documento;

class TxtVisitor
{

public:
	
	virtual void VisitTexto(Documento&) = 0; 

};
#endif