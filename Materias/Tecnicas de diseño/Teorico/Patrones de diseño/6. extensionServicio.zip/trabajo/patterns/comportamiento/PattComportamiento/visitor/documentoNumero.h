/************************************************

  DocumentoNumerico 
  este es la declaracion de la clase que modela
  un DocumentoNumerico de texto, usada como ejemplo para
  distintos patterns

*************************************************/
#ifndef DOCUMENTONUMERICO_H_
#define DOCUMENTONUMERICO_H_

#include"documento.h"

#include <string>


using namespace std;

class DocumentoNumerico : public Documento
{


public:

	DocumentoNumerico(const char* nombre_file);
	
	virtual ~DocumentoNumerico();

	// manejo del contenido como txt
	bool    Print();

   // manejo del file
	bool SaveToFile(const char* nombre_file);
	bool LoadFromFile(const char* nombre_file);

    // access for visitor
	void Accept(DocumentoVisitor& doc);
	void Accept(ElementVisitor&   doc);


private:

    
	DocumentoNumerico(const DocumentoNumerico&);
	DocumentoNumerico& operator=(const DocumentoNumerico&);

protected:
  
	
};
#endif