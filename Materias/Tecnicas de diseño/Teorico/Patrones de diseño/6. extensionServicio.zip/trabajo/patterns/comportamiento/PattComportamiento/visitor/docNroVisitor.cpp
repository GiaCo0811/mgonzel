/************************************************
   Implementacion del pattern acyclic VISITOR

************************************************/
#include "docnrovisitor.h"
#include "documento.h"

#include <vector>

DocNroVisitor::DocNroVisitor()
:count_total(0)
{
   
}
//-----------------------------------------------
void DocNroVisitor::VisitNumero(Documento& doc)
{
	vector<double> datos = doc.GetDatos();

	// se procesa el texto
	vector<double>::iterator  iter = datos.begin();
	while(iter != datos.end()){

           count_total += *iter;
	  	   ++iter;
	}
}
