//-----------------------------------------------
//     Class composed for acyclic visitor
//-----------------------------------------------
#ifndef DOCNROVISITOR_H_
#define DOCNROVISITOR_H_

#pragma warning ( disable : 4786 )

#include "elementvisitor.h"
#include "nrovisitor.h"
#include <iostream>

using namespace std;


class DocNroVisitor : public ElementVisitor, public NroVisitor
{

public:

	DocNroVisitor();

	void VisitNumero(Documento&); 

	void PrintTotal()   { cout << "VISITOR ACICLICO - Total numerico: " << count_total << endl << endl;}

private:
	int count_total;
	
};
#endif