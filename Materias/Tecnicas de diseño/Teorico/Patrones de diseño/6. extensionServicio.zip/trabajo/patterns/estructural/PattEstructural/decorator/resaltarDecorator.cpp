/************************************************

   Decorator : ResaltarDecorator

   guillermo pantaleo 10/2/2002

*************************************************/

#include "decorator.h"


bool ResaltarDecorator::Print()
{

	// aca va el filtrado
	string& el_texto = GetElTexto();
	
    string::size_type i = 0;

    i = el_texto.find("};", i);
    while(i != string::npos ){

	 
	    el_texto.replace(i, strlen("};"), 
            "};\n//************************************");

	    i = el_texto.find("};", i + 10);
	}


	
	el_documento->Print();	
	
	return true;
}