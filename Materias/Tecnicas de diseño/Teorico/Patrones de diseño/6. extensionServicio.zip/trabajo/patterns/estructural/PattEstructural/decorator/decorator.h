/************************************************
  
	DECORATOR
	declaracion de la clase Decorator

    guillermo pantaleo 10/2/2002

************************************************/
#ifndef DECORATOR_H_
#define DECORATOR_H_

#include "documento.h"

#include <iostream>

using namespace std;

class DocumentoDecorator : public Documento
{

public:


	DocumentoDecorator(Documento* un_documento):Documento(un_documento->getNombreFile()){ el_documento = un_documento;}
    virtual ~DocumentoDecorator(){ delete el_documento;}

	// manejo del texto
	virtual string& GetElTexto(){ return el_documento->GetElTexto();}
	virtual void    SetElTexto(string s){ el_documento->SetElTexto(s);}
	virtual bool    Print()=0;
private:

	DocumentoDecorator(const DocumentoDecorator&);
	DocumentoDecorator& operator=(const DocumentoDecorator&);

protected:

	Documento* el_documento;


};

class TituloDecorator : public DocumentoDecorator
{
public:


	TituloDecorator(Documento* un_documento):DocumentoDecorator(un_documento){}
    virtual ~TituloDecorator(){}

	bool    Print();

private:

	TituloDecorator(const TituloDecorator&);
	TituloDecorator& operator=(const TituloDecorator&);


protected:
};

inline bool TituloDecorator::Print()
{

	cout << "IMPRIMIRNDO EL FILE : " << nombre_file << endl << endl;
	el_documento->Print();

	return true;
}

class ReferenciasDecorator : public DocumentoDecorator
{
public:


	ReferenciasDecorator(Documento* un_documento):DocumentoDecorator(un_documento){}
    virtual ~ReferenciasDecorator(){}

	bool    Print();

private:

	ReferenciasDecorator(const ReferenciasDecorator&);
	ReferenciasDecorator& operator=(const ReferenciasDecorator&);


protected:
};

inline bool ReferenciasDecorator::Print()
{

	el_documento->Print();
	cout << "\n\nESTAS SON LAS REFERENCIAS DEL DOCUMENTO" << "\n\n";
	

	return true;
}

class ResaltarDecorator : public DocumentoDecorator
{
public:


	ResaltarDecorator(Documento* un_documento):DocumentoDecorator(un_documento){}
    virtual ~ResaltarDecorator(){}

	bool    Print();

private:

	ResaltarDecorator(const ResaltarDecorator&);
	ResaltarDecorator& operator=(const ResaltarDecorator&);


protected:
};

#endif