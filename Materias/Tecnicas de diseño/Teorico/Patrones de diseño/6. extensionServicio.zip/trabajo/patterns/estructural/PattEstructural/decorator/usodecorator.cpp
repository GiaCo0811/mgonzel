/************************************************

     uso del pattern decorator

     guillermo pantaleo 10/2/2002

************************************************/
#include "documentoTexto.h"
#include "decorator.h"


void main()
{
    char c;

  // uso del documento original
	//DocumentoTexto documentoOriginal("c:\\trabajo\\patterns\\estructural\\PattEstructural\\decorator\\decorator.h");
	//documentoOriginal.Print();

    //cin >> c;

	
	ResaltarDecorator documento( new DocumentoTexto("c:\\trabajo\\patterns\\estructural\\PattEstructural\\decorator\\decorator.h"));
	documento.Print();
    
}