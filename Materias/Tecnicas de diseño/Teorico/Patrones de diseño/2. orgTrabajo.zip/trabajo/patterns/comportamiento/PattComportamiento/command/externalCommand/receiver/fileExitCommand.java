/*
 * fileExitCommand.java
 *
 * Created on September 28, 2002, 9:31 AM
 */
/**
 *
 * @author  guillermo pantaleo
 * @version 
 */
package receiver;
import java.awt.*;
import java.awt.event.*;

public class fileExitCommand extends MenuItem implements Command
   {
      public fileExitCommand(String caption)
      {
         super(caption);
      }
      public void Execute()
      {
         System.exit(0);
      }
   }

