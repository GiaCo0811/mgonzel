package receiver;

public interface Command
{
   public void Execute();
}
