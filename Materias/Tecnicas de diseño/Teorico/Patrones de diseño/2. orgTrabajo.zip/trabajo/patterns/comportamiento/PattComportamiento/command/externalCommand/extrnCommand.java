/*
 *  modificado por guillermo pantaleo
 *  20/09/2002
 *
 **/
import java.awt.*;
import java.awt.event.*;
import receiver.*;

public class extrnCommand extends Frame  implements ActionListener
{
   Menu mnuFile;
   fileOpenCommand mnuOpen;
   fileExitCommand mnuExit;
   btnRedCommand btnRed;
   btnYellowCommand btnYellow;
   Panel p;
   Frame fr;
   //-----------------------------------------
   public extrnCommand()
   {
      super("Frame with external commands");
      fr = this;     //save frame object
      MenuBar mbar = new MenuBar();
      setMenuBar(mbar);

      mnuFile = new Menu("File", true);
      mbar.add(mnuFile);

      mnuOpen = new fileOpenCommand("Open...", this);
      mnuFile.add(mnuOpen);
      mnuExit = new fileExitCommand("Exit");
      mnuFile.add(mnuExit);

      mnuOpen.addActionListener(this);
      mnuExit.addActionListener(this);
      
      p = new Panel();
      add(p);
      btnRed = new btnRedCommand("Red", p);
      btnYellow = new btnYellowCommand("Yellow", p);
      
      p.add(btnRed);
      p.add(btnYellow);
      
      btnRed.addActionListener(this);
      btnYellow.addActionListener(this);
      
      setBounds(100,100,200,100);
      setVisible(true);
   }
   //-----------------------------------------
   public void actionPerformed(ActionEvent e)
   {
      Command obj = (Command)e.getSource();
      obj.Execute();
   }
   //-----------------------------------------
   static public void main(String argv[])
   {
      new extrnCommand();
   }
}
