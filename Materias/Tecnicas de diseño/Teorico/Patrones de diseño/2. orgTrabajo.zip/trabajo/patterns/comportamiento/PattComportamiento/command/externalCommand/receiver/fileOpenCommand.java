/*
 * fileOpenCommand.java
 *
 * Created on September 28, 2002, 9:20 AM
 */

package receiver;
import java.awt.*;
import java.awt.event.*;

public class fileOpenCommand extends MenuItem implements Command
{
  Frame fr;
  public fileOpenCommand(String caption, Frame frm)
  {
     super(caption);
     fr = frm;
  }
  public void Execute()
  {
     FileDialog fDlg=new FileDialog(fr,"Open file");
     fDlg.show();
  }
}

