/*
 * btnRedCommand.java
 *
 * Created on September 28, 2002, 9:36 AM
 */
/**
 *
 * @author  Administrator
 * @version 
 */
package receiver;
import java.awt.*;
import java.awt.event.*;

public class btnRedCommand extends Button implements Command
{
   Panel p;
  public btnRedCommand(String caption, Panel pnl)
  {
     super(caption);
     p = pnl;
  }
  public void Execute()
  {
     p.setBackground(Color.red);
  }
}
