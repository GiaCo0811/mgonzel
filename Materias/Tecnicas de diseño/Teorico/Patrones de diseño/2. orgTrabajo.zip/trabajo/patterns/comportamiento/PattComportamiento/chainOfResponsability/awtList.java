public interface awtList
{
     public void add(String s);
     public void remove(String s);
     public String[] getSelectedItems();

}

